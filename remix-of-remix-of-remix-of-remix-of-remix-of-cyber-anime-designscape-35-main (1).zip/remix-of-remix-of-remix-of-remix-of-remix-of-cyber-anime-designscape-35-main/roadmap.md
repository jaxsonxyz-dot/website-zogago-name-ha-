# Roadmap

- [x] Case Studies system: `/case-studies` listing with category filters, 13 placeholder projects, reusable detail page, nav + footer links
- [x] Tighten Services header spacing and remove beam lights outside the homepage header
- [x] Portfolio cross-linking: Related Case Studies on every service page, service back-link on case study pages
- [x] Expose E-Commerce + Architecture on the Services grid (7 cards, image slots ready for real images)
- [x] Add Pop Culture Creative Studio to logo Project 03 with the first uploaded image as its cover and review the supporting images
