
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import ScrollToTop from "./components/layout/ScrollToTop";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import ThankYou from "./pages/ThankYou";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsAndConditions from "./pages/TermsAndConditions";
import About from "./pages/About";
import Services from "./pages/Services";
import Contact from "./pages/Contact";

// Import service pages
import SEO from "./pages/services/SEO";
import WebDevelopment from "./pages/services/WebDevelopment";
import Ecommerce from "./pages/services/Ecommerce";
import GraphicsDesign from "./pages/services/GraphicsDesign";
import Architecture from "./pages/services/Architecture";
import BrandStrategy from "./pages/services/BrandStrategy";
import SocialMediaMarketing from "./pages/services/SocialMediaMarketing";
import CaseStudyDemo from "./pages/portfolio/CaseStudyDemo";
import CaseStudies from "./pages/CaseStudies";
import CaseStudyDetail from "./pages/CaseStudyDetail";
import "./index.css";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <BrowserRouter>
      <ScrollToTop />
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <div className="bg-zogago-dark">
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/thank-you" element={<ThankYou />} />
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            <Route path="/terms-and-conditions" element={<TermsAndConditions />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/contact" element={<Contact />} />
            
            {/* Service routes */}
            <Route path="/services/seo" element={<SEO />} />
            <Route path="/services/web-development" element={<WebDevelopment />} />
            <Route path="/services/ecommerce" element={<Ecommerce />} />
            <Route path="/services/graphics-design" element={<GraphicsDesign />} />
            <Route path="/services/architecture" element={<Architecture />} />
            <Route path="/services/brand-strategy" element={<BrandStrategy />} />
            <Route path="/services/social-media-marketing" element={<SocialMediaMarketing />} />

            {/* Portfolio case study */}
            <Route path="/portfolio/neon-commerce" element={<CaseStudyDemo />} />

            {/* Case studies */}
            <Route path="/case-studies" element={<CaseStudies />} />
            <Route path="/case-studies/:slug" element={<CaseStudyDetail />} />

            
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </div>
      </TooltipProvider>
    </BrowserRouter>
  </QueryClientProvider>
);

export default App;
