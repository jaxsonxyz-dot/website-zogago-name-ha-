import React, { useState, useEffect, useRef } from 'react';
import { Send, ChevronRight, CheckCircle, Monitor, Brush, Smartphone, FileText, Users, Sparkles, ExternalLink, Wand2, X } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import GlitchText from '../ui/GlitchText';
import { useToast } from "@/hooks/use-toast";
import { saveContactMessage } from '@/lib/storage';
import gsap from 'gsap';
import { Checkbox } from "@/components/ui/checkbox";
import { triggerConfetti } from '@/utils/animations/confettiAnimation';
import { useGeminiAI } from '@/hooks/useGeminiAI';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
interface AboutProps {
  geminiApiKey?: string;
  onApiKeyChange?: (key: string) => void;
}
const serviceOptions = [{
  id: 'webDevelopment',
  label: 'Web Development',
  shortLabel: 'Web Dev'
}, {
  id: 'graphicsDesign',
  label: 'Graphics Design',
  shortLabel: 'Graphics'
}, {
  id: 'socialMediaMarketing',
  label: 'Social Media Marketing',
  shortLabel: 'Social Media'
}, {
  id: 'seo',
  label: 'SEO',
  shortLabel: 'SEO'
}, {
  id: 'ecommerce',
  label: 'E-commerce',
  shortLabel: 'E-commerce'
}, {
  id: 'architecture',
  label: 'Architecture',
  shortLabel: 'Architecture'
}];
const About: React.FC<AboutProps> = ({
  geminiApiKey = '',
  onApiKeyChange
}) => {
  const {
    toast
  } = useToast();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
    services: [] as string[]
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const aboutRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const successSoundRef = useRef<HTMLAudioElement | null>(null);
  const geminiAI = useGeminiAI();
  useEffect(() => {
    successSoundRef.current = new Audio('/success-sound.mp3');
    return () => {
      if (successSoundRef.current) {
        successSoundRef.current.pause();
        successSoundRef.current = null;
      }
    };
  }, []);
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-visible');
          if (entry.target === aboutRef.current) {
            const features = document.querySelectorAll('.bumper-element');
            features.forEach((feature, index) => {
              gsap.set(feature, {
                x: Math.random() * 10 - 5,
                y: Math.random() * 10 - 5
              });
              gsap.to(feature, {
                x: `random(-15, 15)`,
                y: `random(-15, 15)`,
                duration: 2.5,
                ease: "sine.inOut",
                repeat: -1,
                yoyo: true,
                yoyoEase: "power1.inOut",
                delay: index * 0.2
              });
              feature.addEventListener('mouseenter', () => {
                gsap.to(feature, {
                  scale: 1.05,
                  boxShadow: "0 0 20px rgba(31, 182, 250, 0.5)",
                  duration: 0.3
                });
                features.forEach((otherFeature) => {
                  if (otherFeature !== feature) {
                    gsap.to(otherFeature, {
                      x: `random(-20, 20)`,
                      y: `random(-20, 20)`,
                      duration: 0.5,
                      ease: "power2.out"
                    });
                  }
                });
              });
              feature.addEventListener('mouseleave', () => {
                gsap.to(feature, {
                  scale: 1,
                  boxShadow: "0 0 0px rgba(31, 182, 250, 0)",
                  duration: 0.3
                });
              });
            });
          }
        }
      });
    }, {
      threshold: 0.1
    });
    const animatedElements = document.querySelectorAll('.animate-hidden');
    animatedElements.forEach((el) => observer.observe(el));
    if (aboutRef.current) {
      observer.observe(aboutRef.current);
    }
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => {
      animatedElements.forEach((el) => observer.unobserve(el));
      if (aboutRef.current) observer.unobserve(aboutRef.current);
      if (statsRef.current) observer.unobserve(statsRef.current);
    };
  }, []);
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const {
      name,
      value
    } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };
  const handleServiceToggle = (serviceId: string) => {
    setFormData((prev) => {
      const services = prev.services.includes(serviceId) ? prev.services.filter((id) => id !== serviceId) : [...prev.services, serviceId];
      return {
        ...prev,
        services
      };
    });
  };
  const handleExpandText = async () => {
    try {
      const expandedText = await geminiAI.expandText(formData.message);
      setFormData((prev) => ({
        ...prev,
        message: expandedText
      }));
      toast({
        title: "Text Expanded",
        description: "Your message has been enhanced with AI assistance",
        duration: 1500
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to expand text",
        variant: "destructive",
        duration: 2000
      });
    }
  };
  const handleCorrectGrammar = async () => {
    try {
      const result = await geminiAI.correctGrammar(formData.message);
      if (!result.hasErrors) {
        toast({
          title: "Grammar Check Complete",
          description: "Your text is already grammatically correct!",
          duration: 1500
        });
        return;
      }
      setFormData((prev) => ({
        ...prev,
        message: result.correctedText
      }));
      toast({
        title: "Grammar Corrected",
        description: "Your message has been proofread by AI",
        duration: 1500
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to correct grammar",
        variant: "destructive",
        duration: 2000
      });
    }
  };
  const handleSaveApiKey = () => {
    toast({
      title: "AI Ready",
      description: "AI features are powered by Lovable Cloud",
      duration: 2000
    });
  };
  const playSuccessSound = () => {
    if (successSoundRef.current) {
      successSoundRef.current.currentTime = 0;
      successSoundRef.current.play().catch((e) => console.log("Audio play error:", e));
    }
  };
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!acceptTerms) {
      toast({
        title: "Error",
        description: "Please accept terms and conditions to continue",
        variant: "destructive",
        duration: 2000
      });
      return;
    }
    setIsSubmitting(true);
    saveContactMessage({
      name: formData.name,
      email: formData.email,
      message: formData.message,
      services: formData.services
    });
    toast({
      title: "Message sent!",
      description: `Thanks ${formData.name}! We'll be in touch soon.`,
      duration: 3000
    });
    playSuccessSound();
    triggerConfetti();
    setTimeout(() => {
      navigate('/thank-you', {
        state: {
          name: formData.name
        },
        replace: true
      });
    }, 2000);
  };
  return <section id="about" ref={aboutRef} className="zg-section relative overflow-hidden">
      <div className="zg-container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="animate-hidden animate-slide-from-left">
            <div className="inline-block px-4 py-1 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 mb-6">
              <p className="text-sm font-medium text-zogago-light/80">About Us</p>
            </div>
            
            <h2 className="zg-heading-lg mb-6">
              We Create <span className="text-gradient-purple">Digital Magic</span>
            </h2>
            
            <p className="zg-paragraph mb-6">
              ZOGAGO is a team of passionate digital artists, developers, and anime enthusiasts 
              committed to pushing the boundaries of what's possible in digital design.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {["Futuristic Designs", "Creative Innovation", "Anime-Inspired Visuals", "Technical Excellence"].map((item, i) => <div key={i} className="flex items-center space-x-2 animate-hidden animate-fade-in-up bumper-element glass-card p-3 relative" style={{
              animationDelay: `${i * 200}ms`,
              zIndex: 2
            }}>
                  <CheckCircle className="text-zogago-blue h-5 w-5 flex-shrink-0" />
                  <span className="text-zogago-light/80">{item}</span>
                </div>)}
            </div>
            
            <div className="flex items-center space-x-6 animate-hidden animate-fade-in-up" style={{
            animationDelay: "800ms"
          }}>
              <div>
                <div className="font-bold text-3xl text-gradient-blue">5+</div>
                <p className="text-sm text-zogago-light/70">Years Experience</p>
              </div>
              <div className="h-10 w-px bg-white/10"></div>
              <div>
                <div className="font-bold text-3xl text-gradient-blue">100+</div>
                <p className="text-sm text-zogago-light/70">Projects Completed</p>
              </div>
              <div className="h-10 w-px bg-white/10"></div>
              <div>
                <div className="font-bold text-3xl text-gradient-blue">50+</div>
                <p className="text-sm text-zogago-light/70">Happy Clients</p>
              </div>
            </div>
          </div>
          
          <div id="contact" className="glass-card p-4 sm:p-5 animate-hidden animate-slide-from-right">
            {<>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-bold">
                    <GlitchText text="Contact Us" intensity="low" glitchInterval={8000} rgbShift={true} />
                  </h3>
                  
                  
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-3">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-zogago-light/80 mb-1">
                      Name
                    </label>
                    <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-zogago-light text-sm focus:outline-none focus:ring-2 focus:ring-zogago-blue transition-all" placeholder="Your name" required />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-zogago-light/80 mb-1">
                      Email
                    </label>
                    <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-zogago-light text-sm focus:outline-none focus:ring-2 focus:ring-zogago-blue transition-all" placeholder="your.email@example.com" required />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-zogago-light/80 mb-2">
                      <span className="inline-flex items-center gap-1">
                        <span className="text-gradient-purple font-semibold">Customize Your Journey</span> 
                        <span className="animate-pulse">✨</span>
                      </span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                      {serviceOptions.map((service) => <div key={service.id} onClick={() => handleServiceToggle(service.id)} className={`
                            flex items-center justify-center text-center p-2 rounded-md cursor-pointer transition-all min-h-[44px]
                            ${formData.services.includes(service.id) ? 'bg-zogago-blue/20 border border-zogago-blue/50' : 'bg-white/5 border border-white/10 hover:bg-[#11B3EEE6]/20'}
                          `}>
                          <span className="text-xs sm:text-sm leading-snug"><span className="sm:hidden">{service.shortLabel}</span><span className="hidden sm:inline">{service.label}</span></span>
                        </div>)}
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label htmlFor="message" className="block text-sm font-medium text-zogago-light/80">
                        Message
                      </label>
                      
                      {geminiAI.hasApiKey && <div className="flex space-x-2">
                          <button type="button" onClick={handleExpandText} disabled={geminiAI.isProcessing || !formData.message} className="text-xs flex items-center py-1 px-2 rounded bg-zogago-blue/10 text-zogago-blue hover:bg-[#11B3EEE6]/20 disabled:opacity-50 disabled:cursor-not-allowed">
                            <Sparkles className="w-3 h-3 mr-1" />
                            Expand
                          </button>
                          <button type="button" onClick={handleCorrectGrammar} disabled={geminiAI.isProcessing || !formData.message} className="text-xs flex items-center py-1 px-2 rounded bg-zogago-blue/10 text-zogago-blue hover:bg-[#11B3EEE6]/20 disabled:opacity-50 disabled:cursor-not-allowed">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Fix Grammar
                          </button>
                        </div>}
                    </div>
                    
                    <textarea id="message" name="message" value={formData.message} onChange={handleChange} rows={2} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-zogago-light text-sm focus:outline-none focus:ring-2 focus:ring-zogago-blue transition-all" placeholder={geminiAI.isProcessing ? "Processing with AI..." : "Tell us about your project..."} required disabled={geminiAI.isProcessing} />
                  </div>
                  
                  <div className="flex items-start space-x-2">
                    <Checkbox id="terms1" checked={acceptTerms} onCheckedChange={(checked) => setAcceptTerms(checked as boolean)} className="bg-white/10 border-white/20 mt-1" />
                    <div className="grid gap-1.5 leading-none">
                      <label htmlFor="terms1" className="text-sm font-medium text-zogago-light/80 leading-tight cursor-pointer">
                        I accept the 
                        <Link to="/terms-and-conditions" className="text-zogago-blue hover:text-zogago-blue/80 mx-1 underline">
                          Terms and Conditions
                        </Link>
                        and 
                        <Link to="/privacy-policy" className="text-zogago-blue hover:text-zogago-blue/80 mx-1 underline">
                          Privacy Policy
                        </Link>
                      </label>
                    </div>
                  </div>
                  
                  <button type="submit" disabled={isSubmitting} className="button-glow w-full group">
                    <span className="relative z-10 flex items-center justify-center">
                      {isSubmitting ? "Sending..." : <>
                          Send Message
                          <Send className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                        </>}
                    </span>
                  </button>
                </form>
              </>}
          </div>
        </div>
      </div>

    </section>;
};
export default About;