import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';

import ParticlesComponent from '../ui/particles-bg';

const Hero = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  const buttonRef = useRef<HTMLButtonElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {

    const visibilityTimer = setTimeout(() => {
      setIsVisible(true);
    }, 300);

    // Matrix rain removed — replaced by particles.js

    // Removed: scroll particles, grid mousemove handler — minimal visual impact, significant CPU cost

    const handleMouseMove = (e: MouseEvent) => {
      if (!buttonRef.current) return;
      const { clientX, clientY } = e;
      const buttonRect = buttonRef.current.getBoundingClientRect();
      const buttonCenterX = buttonRect.left + buttonRect.width / 2;
      const buttonCenterY = buttonRect.top + buttonRect.height / 2;
      const distanceX = clientX - buttonCenterX;
      const distanceY = clientY - buttonCenterY;
      const angle = Math.atan2(distanceY, distanceX) * (180 / Math.PI);
      buttonRef.current.style.setProperty('--glow-direction', `${angle}deg`);
    };

    document.addEventListener('mousemove', handleMouseMove);

    return () => {
      clearTimeout(visibilityTimer);
      document.removeEventListener('mousemove', handleMouseMove);
      
    };
  }, []);

  const handleGetStarted = () => {
    const servicesSection = document.getElementById('services');
    if (servicesSection) {
      servicesSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const taglineVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, delay: 0.9, ease: "easeOut" }
    }
  };

  const wordAnimation = {
    hidden: { opacity: 0, y: 15 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: { delay: 1.0 + i * 0.1, duration: 0.5, ease: "easeOut" }
    })
  };

  const taglineWords = "Fulfill your desire - Convert your imagination into reality with ZOGAGOVISUALS".split(" ");

  // Detect small screen for conditional rendering
  const isSmallScreen = typeof window !== 'undefined' && window.innerWidth < 640;

  return (
    <div
      ref={heroRef}
      className={`relative min-h-[60vh] sm:min-h-[70vh] md:min-h-[80vh] flex items-center overflow-hidden pt-16 sm:pt-20 pb-8 transition-all duration-1000 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-20'}`}>
      
      {/* Video Background */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <video
          ref={videoRef}
          autoPlay
          loop
          muted
          playsInline
          className={`absolute w-full h-full object-cover transition-opacity duration-1500 ${
            isVisible ? 'opacity-30' : 'opacity-0'}`}
          style={{ filter: 'brightness(0.4) contrast(1.2) saturate(1.2)' }}>
          <source src="/video-background.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-gradient-to-t from-zogago-dark via-transparent to-transparent opacity-80"></div>
      </div>
      
      {/* Interactive Particles Background */}
      <ParticlesComponent />
      
      {/* Glowing Orbs — CSS only, very lightweight */}
      <div className={`absolute top-1/4 right-1/4 w-96 h-96 rounded-full bg-cyan-500/20 filter blur-[100px] animate-pulse-slow transition-all duration-2000 delay-500 ${
        isVisible ? 'opacity-100' : 'opacity-0'}`}></div>
      <div className={`absolute bottom-1/4 left-1/4 w-96 h-96 rounded-full bg-cyan-400/20 filter blur-[100px] animate-pulse-slow transition-all duration-2000 delay-800 ${
        isVisible ? 'opacity-100' : 'opacity-0'}`}></div>
      
      {/* Content */}
      <div className="zg-container relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className={`inline-block px-4 py-1 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 mb-5 transition-all duration-700 delay-300 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <p className="text-sm font-medium text-zogago-light/80">
              Creative Tech Brand
            </p>
          </div>
          
          <h1 className={`text-2xl xs:text-3xl sm:text-4xl md:text-5xl lg:text-6xl mb-3 sm:mb-4 font-bold leading-tight transition-all duration-700 delay-500 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <span className="text-gradient-blue">Futuristic Design</span> Meets{" "}
            <span className="text-gradient-purple">Anime Aesthetics</span>
          </h1>
          
          <motion.div
            className="mb-4"
            variants={taglineVariants}
            initial="hidden"
            animate={isVisible ? "visible" : "hidden"}>
            <div className="flex flex-wrap justify-center gap-x-1.5 sm:gap-x-2 px-2">
              {taglineWords.map((word, i) =>
                <motion.span
                  key={i}
                  custom={i}
                  variants={wordAnimation}
                  initial="hidden"
                  animate={isVisible ? "visible" : "hidden"}
                  className="inline-block text-sm sm:text-base md:text-lg lg:text-xl font-medium text-white/95 sm:text-gradient-blue drop-shadow-sm">
                  {word}
                </motion.span>
              )}
            </div>
          </motion.div>
          
          <div className={`flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4 transition-all duration-700 delay-900 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <button
              ref={buttonRef}
              onClick={handleGetStarted}
              className="button-glow group px-8 py-3 text-base font-medium transition-transform duration-300 hover:scale-105">
              <span className="relative z-10 flex items-center">
                Explore
                <ChevronRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
