
import React, { useState, useEffect } from 'react';
import IntroAnimation from '../ui/IntroAnimation';

interface HomeIntroProps {
  onIntroComplete: () => void;
}

const INTRO_SHOWN_KEY = 'zogago_intro_shown';

const HomeIntro: React.FC<HomeIntroProps> = ({ onIntroComplete }) => {
  const [showIntro, setShowIntro] = useState(false);
  
  // Check if intro has been shown before
  useEffect(() => {
    // Check localStorage first
    const introShown = localStorage.getItem(INTRO_SHOWN_KEY);
    
    // Only show intro on first visit to save the animation for first impression
    if (!introShown) {
      setShowIntro(true);
      // Set after showing once so it won't show again on refresh
      localStorage.setItem(INTRO_SHOWN_KEY, 'true');
    } else {
      onIntroComplete();
    }
  }, [onIntroComplete]);
  
  // Handle intro animation completion
  const handleIntroComplete = () => {
    setShowIntro(false);
    onIntroComplete();
  };
  
  if (!showIntro) return null;
  
  return <IntroAnimation onAnimationComplete={handleIntroComplete} />;
};

export default HomeIntro;
