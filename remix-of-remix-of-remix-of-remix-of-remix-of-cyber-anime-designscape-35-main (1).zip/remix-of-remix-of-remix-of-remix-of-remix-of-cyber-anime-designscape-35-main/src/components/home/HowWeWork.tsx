import React, { useEffect, useRef, useState } from 'react';
import { MessageSquare, Palette, Code, Rocket } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface ProcessStep {
  id: number;
  icon: React.ElementType;
  title: string;
  description: string;
  color: string;
  bgColor: string;
}

const processSteps: ProcessStep[] = [
  {
    id: 1,
    icon: MessageSquare,
    title: "Discovery & Strategy",
    description: "We dive into your goals, audience, and competitors to define a clear, result-driven roadmap.",
    color: "text-zogago-blue",
    bgColor: "bg-zogago-blue/10"
  },
  {
    id: 2,
    icon: Palette,
    title: "Design & Prototyping",
    description: "Wireframes and high-fidelity visuals are crafted to match your brand and user expectations.",
    color: "text-zogago-purple",
    bgColor: "bg-zogago-purple/10"
  },
  {
    id: 3,
    icon: Code,
    title: "Development & Refinement",
    description: "We build fast, responsive, and scalable solutions while iterating based on your feedback.",
    color: "text-zogago-pink",
    bgColor: "bg-zogago-pink/10"
  },
  {
    id: 4,
    icon: Rocket,
    title: "Launch & Support",
    description: "Your project goes live with performance tuning, training, and ongoing support included.",
    color: "text-cyan-400",
    bgColor: "bg-cyan-400/10"
  }
];

const HowWeWork = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="process"
      ref={sectionRef}
      className="zg-section relative overflow-hidden bg-gradient-to-b from-zogago-dark to-black/60"
    >
      {/* Top divider */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-zogago-purple/50 to-transparent"></div>

      {/* Background glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-zogago-blue/10 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="zg-container relative z-10">
        {/* Header */}
        <motion.div
          className="text-center max-w-3xl mx-auto mb-10 md:mb-14"
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : undefined}
          transition={{ duration: 0.7, ease: 'easeOut' }}
        >
          <div className="inline-block px-4 py-1 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 mb-4">
            <p className="text-sm font-medium text-zogago-light/80">How We Work</p>
          </div>
          <h2 className="zg-heading-lg mb-4">
            From Idea to <span className="text-gradient-purple">Launch</span>
          </h2>
          <p className="zg-paragraph">
            A simple, transparent process designed to keep you in the loop and deliver work that hits the mark.
          </p>
        </motion.div>

        {/* Steps */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {processSteps.map((step, index) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.id}
                className="relative group"
                initial={{ opacity: 0, y: 40 }}
                animate={isVisible ? { opacity: 1, y: 0 } : undefined}
                transition={{
                  duration: 0.6,
                  delay: index * 0.12,
                  ease: [0.25, 1, 0.5, 1]
                }}
              >
                <div
                  className={cn(
                    "glass-card h-full p-5 sm:p-6 transition-all duration-500 hover:border-white/20 hover:bg-white/10 group-hover:shadow-[0_0_30px_-8px_rgba(31,182,250,0.25)]",
                    isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-20"
                  )}
                >
                  {/* Step number */}
                  <div className="absolute -top-3 -right-2 text-5xl font-bold text-white/5 select-none">
                    0{step.id}
                  </div>

                  {/* Icon */}
                  <div
                    className={cn(
                      "w-11 h-11 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center mb-4 transition-transform duration-300 group-hover:scale-110",
                      step.bgColor
                    )}
                  >
                    <Icon className={cn("w-5 h-5 sm:w-6 sm:h-6", step.color)} />
                  </div>

                  {/* Content */}
                  <h3 className="text-base sm:text-lg font-bold text-white mb-2 group-hover:text-zogago-blue transition-colors duration-300">
                    {step.title}
                  </h3>
                  <p className="text-sm text-zogago-light/70 leading-relaxed">
                    {step.description}
                  </p>
                </div>

                {/* Connector line for desktop */}
                {index < processSteps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-px bg-gradient-to-r from-white/20 to-transparent transform -translate-y-1/2 z-0"></div>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <motion.div
          className="mt-10 md:mt-14 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : undefined}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <p className="text-sm text-zogago-light/70 mb-4">
            Ready to see how we can transform your next project?
          </p>
          <a
            href="#about"
            className="button-glow group inline-flex items-center"
            onClick={(e) => {
              e.preventDefault();
              const aboutSection = document.getElementById('about');
              if (aboutSection) {
                aboutSection.scrollIntoView({ behavior: 'smooth' });
              }
            }}
          >
            <span className="relative z-10 flex items-center">
              Start a Project
              <Rocket className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </span>
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default HowWeWork;
