import React, { useEffect, useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Code, ShoppingCart, Palette, Building2, Share2 } from 'lucide-react';
import GlitchText from '../ui/GlitchText';
import { Button } from '../ui/button';
import { cn } from '@/lib/utils';
import { 
  create3DTiltEffect, 
  createGlowingBorderEffect, 
  createPulseAnimation,
  createStaggeredAnimation,
  createCounterAnimation
} from '../../utils/animationUtils';
import gsap from 'gsap';

interface ServiceProps {
  icon: React.ElementType;
  title: string;
  description: string;
  offerings: string[];
  route: string;
  accentColor: string;
  index: number;
}

const ServiceCard: React.FC<ServiceProps> = ({
  icon: Icon,
  title,
  description,
  offerings,
  route,
  accentColor,
  index,
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const iconRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const isPopupVisible = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true);
          
          // Add pop-up animation
          if (cardRef.current && !isPopupVisible.current) {
            isPopupVisible.current = true;
            gsap.fromTo(cardRef.current,
              { 
                scale: 0.8, 
                opacity: 0,
                y: 40
              },
              { 
                scale: 1, 
                opacity: 1, 
                y: 0,
                duration: 0.7, 
                delay: index * 0.2,
                ease: "elastic.out(1, 0.5)"
              }
            );
          }
          
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    const handleMouseMove = (e: MouseEvent) => {
      if (cardRef.current) {
        const rect = cardRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        setMousePosition({ x, y });
      }
    };

    if (cardRef.current) {
      cardRef.current.addEventListener('mousemove', handleMouseMove);
    }

    return () => {
      if (cardRef.current) {
        observer.unobserve(cardRef.current);
        cardRef.current.removeEventListener('mousemove', handleMouseMove);
      }
    };
  }, []);

  const handleServiceClick = (e: React.MouseEvent, route: string) => {
    e.preventDefault();
    
    // Add pop animation on click
    if (cardRef.current) {
      gsap.to(cardRef.current, {
        scale: 1.05,
        duration: 0.2,
        ease: "power1.out",
        onComplete: () => {
          gsap.to(cardRef.current, {
            scale: 1,
            duration: 0.3,
            ease: "elastic.out(1, 0.5)",
            onComplete: () => navigate(route)
          });
        }
      });
    } else {
      navigate(route);
    }
  };

  return (
    <div 
      ref={cardRef}
      className={cn(
        "service-card glass-card p-2.5 sm:p-4 transition-all duration-700 transform group flex flex-col",
        isVisible ? "opacity-100" : "opacity-0"
      )}
      style={{ 
        transitionTimingFunction: "cubic-bezier(0.34, 1.56, 0.64, 1)",
        '--mouse-x': `${mousePosition.x}px`,
        '--mouse-y': `${mousePosition.y}px`
      } as React.CSSProperties}
    >
      <div className="relative overflow-hidden rounded-xl mb-1.5 sm:mb-2">
        <div 
          ref={iconRef}
          className={cn(
            "w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center rounded-lg transition-all duration-500 group-hover:scale-110",
            accentColor
          )}
        >
          <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white transition-transform duration-300 group-hover:rotate-12" />
        </div>
        <div className={cn(
          "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-2xl",
          accentColor
        )} style={{ zIndex: -1 }} />
      </div>
      
      <h3 className="text-xs sm:text-sm md:text-base font-bold mb-0.5 sm:mb-1 group-hover:text-zogago-blue transition-colors duration-300 leading-tight">{title}</h3>
      <p className="text-zogago-light/70 text-[10px] sm:text-xs mb-1.5 sm:mb-2 line-clamp-2 leading-snug">{description}</p>
      
      <div className="mb-2 sm:mb-3 flex-1">
        <h4 className="text-[10px] sm:text-xs font-semibold uppercase tracking-wider text-zogago-light/50 mb-0.5 sm:mb-1">Services</h4>
        <ul className="space-y-0">
          {offerings.map((offering, i) => (
            <li key={i} className="flex items-start group/item">
              <span className="text-zogago-blue mr-1 sm:mr-2 text-[10px] sm:text-xs shrink-0">•</span> 
              <span className="text-zogago-light/70 text-[10px] sm:text-xs leading-tight">{offering}</span>
            </li>
          ))}
        </ul>
      </div>
      
      <div className="mt-auto">
        <a 
          href={route}
          onClick={(e) => handleServiceClick(e, route)}
        >
          <Button 
            variant="default" 
            size="sm"
            className="button-glow w-full transition-all duration-300 hover:shadow-lg font-medium text-[10px] sm:text-xs h-7 sm:h-9"
          >
            <span>View Our Work</span>
          </Button>
        </a>
      </div>
    </div>
  );
};

const ProfessionalServices = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  
  const services = [
    {
      icon: Search,
      title: "SEO",
      description: "Boost your online visibility and drive organic traffic with our comprehensive SEO services designed to improve your search engine rankings.",
      offerings: [
        "On-Page SEO Optimization",
        "Off-Page & Link Building",
        "Keyword Research & Strategy",
        "Technical SEO Audit"
      ],
      route: "/services/seo",
      accentColor: "bg-zogago-blue"
    },
    {
      icon: Code,
      title: "Web Design & Development",
      description: "Transform your digital presence with custom websites that combine stunning designs with powerful functionality.",
      offerings: [
        "Custom Website Design",
        "WordPress Development",
        "E-commerce Website Development",
        "UI/UX Optimization"
      ],
      route: "/services/web-development",
      accentColor: "bg-zogago-purple"
    },
    {
      icon: ShoppingCart,
      title: "E-commerce Store Design",
      description: "Create seamless online shopping experiences with our tailored e-commerce solutions that drive conversions and sales.",
      offerings: [
        "Shopify & WooCommerce Store Setup",
        "Custom E-commerce Design",
        "Mobile & Desktop Optimization",
        "Payment Integration"
      ],
      route: "/services/ecommerce",
      accentColor: "bg-zogago-pink"
    },
    {
      icon: Palette,
      title: "Graphics Design",
      description: "Elevate your brand with eye-catching visual designs that communicate your message and leave a lasting impression.",
      offerings: [
        "Logo & Branding Design",
        "Social Media Graphics",
        "Brochures & Flyers",
        "Business Cards"
      ],
      route: "/services/graphics-design",
      accentColor: "bg-blue-500"
    },
    {
      icon: Building2,
      title: "Architecture",
      description: "Transform spaces with our innovative architectural designs that blend form and function for stunning, practical environments.",
      offerings: [
        "Residential Architecture",
        "Commercial Building Design",
        "3D Architectural Visualization",
        "Sustainable Building Solutions"
      ],
      route: "/services/architecture",
      accentColor: "bg-zogago-purple"
    },
    {
      icon: Share2,
      title: "Social Media Marketing",
      description: "Grow your online presence with strategic social media marketing designed to engage audiences and drive meaningful results.",
      offerings: [
        "Social Media Strategy Development",
        "Content Creation & Curation",
        "Community Management",
        "Social Media Analytics & Reporting"
      ],
      route: "/services/social-media-marketing",
      accentColor: "bg-zogago-blue"
    }
  ];

  useEffect(() => {
    document.documentElement.style.scrollBehavior = 'smooth';
    
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true);
          
          // Add header animation
          if (sectionRef.current) {
            const header = sectionRef.current.querySelector('h2');
            const subtitle = sectionRef.current.querySelector('p');
            
            if (header) {
              gsap.fromTo(header,
                { opacity: 0, y: -30 },
                { 
                  opacity: 1, 
                  y: 0, 
                  duration: 0.8,
                  ease: "power2.out"
                }
              );
            }
            
            if (subtitle) {
              gsap.fromTo(subtitle,
                { opacity: 0, y: -20 },
                { 
                  opacity: 1, 
                  y: 0, 
                  duration: 0.8,
                  delay: 0.2,
                  ease: "power2.out"
                }
              );
            }
          }
          
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    // Apply the bumper car animation to the heading text
    if (headingRef.current) {
      const applyBumpingAnimation = () => {
        const text = "Professional Services That Elevate Your Brand";
        headingRef.current!.innerHTML = '';
        
        // Create spans for each word to apply bumping animation
        text.split(' ').forEach((word, wordIndex) => {
          const wordSpan = document.createElement('span');
          wordSpan.className = 'inline-block mx-1';
          
          // Create spans for each character in the word
          [...word].forEach((char, charIndex) => {
            const charSpan = document.createElement('span');
            charSpan.textContent = char;
            charSpan.className = 'inline-block';
            
            // Apply gradient classes based on the word
            if (wordIndex === 0) {
              charSpan.classList.add('text-gradient-blue');
            } else if (wordIndex === 4) {
              charSpan.classList.add('text-gradient-purple');
            }
            
            // Apply bumper car animation (single time)
            gsap.fromTo(charSpan,
              { 
                y: 0 
              },
              { 
                y: -10,
                duration: 0.3,
                delay: (wordIndex * 0.1) + (charIndex * 0.05),
                ease: "power2.out",
                yoyo: true,
                repeat: 1,
                onComplete: () => {
                  // Add a slight wobble effect after the main animation
                  if (charSpan) {
                    gsap.to(charSpan, {
                      rotation: charIndex % 2 === 0 ? 5 : -5,
                      duration: 0.2,
                      yoyo: true,
                      repeat: 1
                    });
                  }
                }
              }
            );
            
            wordSpan.appendChild(charSpan);
          });
          
          headingRef.current!.appendChild(wordSpan);
          
          // Add a space after each word except the last one
          if (wordIndex < text.split(' ').length - 1) {
            const space = document.createElement('span');
            space.innerHTML = '&nbsp;';
            headingRef.current!.appendChild(space);
          }
        });
      };
      
      // Apply the animation when the element becomes visible
      const animationObserver = new IntersectionObserver(
        (entries) => {
          if (entries[0].isIntersecting) {
            applyBumpingAnimation();
            animationObserver.disconnect();
          }
        },
        { threshold: 0.5 }
      );
      
      animationObserver.observe(headingRef.current);
    }
    
    if (cardsRef.current) {
      const cardElements = cardsRef.current.querySelectorAll('.service-card');
      const iconElements = cardsRef.current.querySelectorAll('.service-card .rounded-xl');
      
      const tiltCleanup = create3DTiltEffect(cardElements, {
        perspective: 1500,
        tiltAmount: 10,
        scale: 1.03,
        speed: 0.6
      });
      
      const glowCleanup = createGlowingBorderEffect(cardElements, {
        color: '#1FB6FA',
        duration: 3,
        blur: 10,
        width: 2,
        intensity: 0.4
      });
      
      const pulseCleanup = createPulseAnimation(iconElements, {
        scale: 1.2,
        duration: 0.4,
        ease: "elastic.out(1, 0.3)",
        repeat: 1
      });
      
      return () => {
        tiltCleanup();
        glowCleanup();
        pulseCleanup();
      };
    }
    
    return () => {
      document.documentElement.style.scrollBehavior = '';
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section 
      id="services" 
      ref={sectionRef}
      className="zg-section relative overflow-hidden pt-8 sm:pt-10"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-zogago-dark to-black/50 z-0"></div>
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-zogago-blue/50 to-transparent"></div>
      
      <div className="zg-container relative z-10">
        <div className={`text-center max-w-3xl mx-auto mb-8 transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-20'
        }`}>
          <h2 ref={headingRef} className="text-xl sm:text-2xl md:text-3xl mb-3 font-bold">
            Professional Services That Elevate Your Brand
          </h2>
          
          <p className="text-xs sm:text-sm text-zogago-light/70">
            We blend cutting-edge technology with creative expertise to deliver digital solutions that help you stand out in today's competitive landscape. Our comprehensive range of services is designed to transform your vision into reality.
          </p>
        </div>
        
        <div ref={cardsRef} className="grid grid-cols-2 md:grid-cols-3 gap-2 sm:gap-3 md:gap-4">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              index={index}
              icon={service.icon}
              title={service.title}
              description={service.description}
              offerings={service.offerings}
              route={service.route}
              accentColor={service.accentColor}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProfessionalServices;
