import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUpRight, Pause, Play, Volume2, VolumeX, Maximize, ChevronLeft, ChevronRight } from 'lucide-react';
import { caseStudies } from '@/data/caseStudies';

/**
 * Set this to your showreel MP4/WebM URL. While empty, the frame plays an
 * animated reel built from your real case study covers.
 */
const SHOWREEL_VIDEO_URL = '';
const SLIDE_MS = 3500;

const slides = caseStudies.filter((c) => c.hero.src).slice(0, 10);

const ShowreelSection = () => {
  const frameRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(true);
  const [index, setIndex] = useState(0);
  const hasVideo = Boolean(SHOWREEL_VIDEO_URL);

  useEffect(() => {
    if (hasVideo || !playing || slides.length < 2) return;
    const t = setInterval(() => setIndex((i) => (i + 1) % slides.length), SLIDE_MS);
    return () => clearInterval(t);
  }, [playing, hasVideo]);

  const togglePlay = () => {
    const v = videoRef.current;
    if (v) (playing ? v.pause() : v.play());
    setPlaying((p) => !p);
  };
  const toggleMute = () => {
    if (videoRef.current) videoRef.current.muted = !muted;
    setMuted((m) => !m);
  };
  const fullscreen = () => frameRef.current?.requestFullscreen?.();

  const current = slides[index];

  return (
    <section id="showreel" className="zg-section relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-zogago-blue/50 to-transparent" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[70%] h-[60%] bg-zogago-purple/20 rounded-full blur-[140px] pointer-events-none" />

      <div className="zg-container relative z-10">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-10 md:mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <div className="inline-block px-4 py-1 rounded-full bg-white/5 border border-white/10 mb-4">
            <p className="text-sm font-medium text-zogago-light/80">Selected Work in Motion</p>
          </div>
          <h2 className="zg-heading-lg mb-4">
            Our <span className="text-gradient-blue">Showreel</span>
          </h2>
          <p className="zg-paragraph">A quick look at the brands, identities and experiences we've crafted.</p>
        </motion.div>

        <motion.div
          ref={frameRef}
          className="group relative mx-auto max-w-5xl aspect-video rounded-2xl overflow-hidden border border-white/10 bg-zogago-dark shadow-[0_0_60px_-10px_hsl(199_95%_55%/0.45)]"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          {hasVideo ? (
            <video ref={videoRef} src={SHOWREEL_VIDEO_URL} autoPlay muted loop playsInline className="w-full h-full object-cover" />
          ) : (
            <AnimatePresence mode="sync">
              {current && (
                <motion.img
                  key={current.slug}
                  src={current.hero.src}
                  alt={current.hero.alt || current.name}
                  className="absolute inset-0 w-full h-full object-cover"
                  initial={{ opacity: 0, scale: 1.12 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ opacity: { duration: 0.9 }, scale: { duration: SLIDE_MS / 1000 + 1, ease: 'linear' } }}
                />
              )}
            </AnimatePresence>
          )}

          <div className="absolute inset-0 bg-gradient-to-t from-zogago-dark/90 via-transparent to-zogago-dark/20 pointer-events-none" />

          {!hasVideo && current && (
            <Link
              to={`/case-studies/${current.slug}`}
              className="absolute left-4 bottom-16 sm:left-6 sm:bottom-20 text-left"
            >
              <p className="text-xs uppercase tracking-widest text-zogago-blue">{current.category}</p>
              <p className="text-lg sm:text-2xl font-bold text-white hover:text-zogago-blue transition-colors">
                {current.name.split(' — ')[0]}
              </p>
            </Link>
          )}

          {/* Controls */}
          <div className="absolute bottom-0 inset-x-0 p-3 sm:p-4 flex items-center gap-3">
            <button onClick={togglePlay} aria-label={playing ? 'Pause' : 'Play'} className="p-2 rounded-full bg-white/10 backdrop-blur hover:bg-white/20 text-white">
              {playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>
            {hasVideo && (
              <button onClick={toggleMute} aria-label={muted ? 'Unmute' : 'Mute'} className="p-2 rounded-full bg-white/10 backdrop-blur hover:bg-white/20 text-white">
                {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            )}
            {!hasVideo && (
              <div className="flex-1 flex sm:hidden items-center justify-center gap-2">
                <button onClick={() => setIndex((i) => (i - 1 + slides.length) % slides.length)} aria-label="Previous project" className="h-10 w-10 flex items-center justify-center rounded-full bg-white/10 backdrop-blur text-white">
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <span className="px-3 py-1.5 rounded-full bg-black/50 backdrop-blur font-mono text-xs text-white">
                  {String(index + 1).padStart(2, '0')} / {String(slides.length).padStart(2, '0')}
                </span>
                <button onClick={() => setIndex((i) => (i + 1) % slides.length)} aria-label="Next project" className="h-10 w-10 flex items-center justify-center rounded-full bg-white/10 backdrop-blur text-white">
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            )}
            {!hasVideo && (
              <div className="flex-1 hidden sm:flex gap-1.5">
                {slides.map((s, i) => (
                  <button
                    key={s.slug}
                    onClick={() => setIndex(i)}
                    aria-label={`Show ${s.name}`}
                    className="flex-1 h-1 rounded-full bg-white/20 overflow-hidden"
                  >
                    <span
                      className={`block h-full bg-zogago-blue transition-all ${i === index ? 'w-full duration-[3500ms] ease-linear' : i < index ? 'w-full duration-0' : 'w-0 duration-0'}`}
                    />
                  </button>
                ))}
              </div>
            )}
            {hasVideo && <div className="flex-1" />}
            <button onClick={fullscreen} aria-label="Fullscreen" className="p-2 rounded-full bg-white/10 backdrop-blur hover:bg-white/20 text-white">
              <Maximize className="w-4 h-4" />
            </button>
          </div>
        </motion.div>

        <div className="mt-10 text-center">
          <Link to="/case-studies" className="button-glow group inline-flex items-center">
            <span className="relative z-10 flex items-center">
              View All Case Studies
              <ArrowUpRight className="ml-2 w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </span>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ShowreelSection;
