import React, { useState, useEffect, useRef } from 'react';
import { useInView } from 'react-intersection-observer';
import { TrendingUp, Award, Zap, Heart } from 'lucide-react';
import gsap from 'gsap';

interface StatItem {
  id: number;
  value: number;
  suffix: string;
  label: string;
  description: string;
  icon: React.ReactNode;
  color: string;
}

const Statistics = () => {
  const [stats, setStats] = useState<StatItem[]>([
    {
      id: 1,
      value: 0,
      suffix: "+",
      label: "Projects Delivered",
      description: "Successfully completed projects",
      icon: <TrendingUp className="h-6 w-6" strokeWidth={1.5} />,
      color: "from-blue-500 to-cyan-500"
    },
    {
      id: 2,
      value: 0,
      suffix: "%",
      label: "Client Satisfaction",
      description: "Happy clients worldwide",
      icon: <Heart className="h-6 w-6" strokeWidth={1.5} />,
      color: "from-purple-500 to-pink-500"
    },
    {
      id: 3,
      value: 0,
      suffix: "+",
      label: "Expert Team",
      description: "Talented professionals",
      icon: <Award className="h-6 w-6" strokeWidth={1.5} />,
      color: "from-orange-500 to-red-500"
    },
    {
      id: 4,
      value: 0,
      suffix: "+",
      label: "Years Experience",
      description: "Industry expertise",
      icon: <Zap className="h-6 w-6" strokeWidth={1.5} />,
      color: "from-green-500 to-emerald-500"
    }
  ]);

  const targetValues = [150, 98, 25, 8];
  const containerRef = useRef<HTMLDivElement>(null);

  const { ref, inView } = useInView({
    threshold: 0.3,
    triggerOnce: true
  });

  useEffect(() => {
    if (inView && containerRef.current) {
      // Animate each stat card with unique animations
      stats.forEach((stat, index) => {
        const card = containerRef.current?.querySelector(`[data-stat-card="${index}"]`);
        if (!card) return;

        // Staggered entrance animation
        gsap.fromTo(card,
          {
            opacity: 0,
            y: 100,
            rotateY: -20,
            scale: 0.8
          },
          {
            opacity: 1,
            y: 0,
            rotateY: 0,
            scale: 1,
            duration: 1.2,
            delay: index * 0.2,
            ease: "power3.out"
          }
        );

        // Animate icon
        const icon = card.querySelector('[data-stat-icon]');
        if (icon) {
          gsap.fromTo(icon,
            { scale: 0, rotation: -180 },
            {
              scale: 1,
              rotation: 0,
              duration: 0.8,
              delay: index * 0.2 + 0.4,
              ease: "back.out(2)"
            }
          );
        }

        // Counter animation
        const counter = card.querySelector(`[data-counter="${index}"]`);
        if (counter) {
          gsap.to(counter, {
            innerHTML: targetValues[index],
            duration: 2.5,
            delay: index * 0.2 + 0.5,
            ease: "power2.out",
            snap: { innerHTML: 1 },
            onUpdate: function() {
              const newStats = [...stats];
              newStats[index] = {
                ...newStats[index],
                value: Math.round(gsap.getProperty(counter, "innerHTML") as number)
              };
              setStats(newStats);
            }
          });
        }
      });
    }
  }, [inView]);

  return (
    <section className="relative py-12 sm:py-16 overflow-hidden bg-gradient-to-br from-zogago-dark via-black to-zogago-dark/80" ref={ref}>
      {/* Background decorative elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-10 left-10 w-72 h-72 bg-zogago-blue/30 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-zogago-purple/30 rounded-full blur-[120px]"></div>
      </div>

      <div className="zg-container relative z-10" ref={containerRef}>
        {/* Header */}
        <div className="text-center mb-8 space-y-2">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-zogago-blue via-zogago-purple to-zogago-blue bg-clip-text text-transparent">
            Transforming Ideas Into Reality
          </h2>
          <p className="text-zogago-light/70 text-sm max-w-2xl mx-auto">
            Our track record speaks for itself. Join hundreds of satisfied clients worldwide.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {stats.map((stat, index) => (
            <div
              key={stat.id}
              data-stat-card={index}
              className="group relative"
            >
              {/* Glow effect on hover */}
              <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-500 rounded-2xl`}></div>
              
              {/* Card */}
              <div className="relative h-full backdrop-blur-xl bg-white/5 border border-white/10 rounded-xl p-4 sm:p-5 hover:border-white/20 transition-all duration-500 hover:shadow-2xl hover:shadow-zogago-blue/10">
                {/* Icon */}
                <div 
                  data-stat-icon
                  className={`mb-3 inline-flex p-2.5 rounded-lg bg-gradient-to-br ${stat.color} shadow-lg`}
                >
                  <div className="text-white">
                    {stat.icon}
                  </div>
                </div>

                {/* Value */}
                <div className="mb-1">
                  <span className={`text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-br ${stat.color} bg-clip-text text-transparent`}>
                    <span data-counter={index}>{stat.value}</span>
                    {stat.suffix}
                  </span>
                </div>

                {/* Label */}
                <h3 className="text-sm sm:text-base font-semibold text-white mb-1">
                  {stat.label}
                </h3>

                {/* Description */}
                <p className="text-zogago-light/60 text-sm">
                  {stat.description}
                </p>

                {/* Decorative corner */}
                <div className={`absolute top-0 right-0 w-20 h-20 bg-gradient-to-br ${stat.color} opacity-10 blur-2xl rounded-full`}></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Statistics;