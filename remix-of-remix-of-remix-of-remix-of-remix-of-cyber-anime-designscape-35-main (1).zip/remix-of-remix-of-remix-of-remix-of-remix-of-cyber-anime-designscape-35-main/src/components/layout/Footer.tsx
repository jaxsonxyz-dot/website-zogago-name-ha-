
import React, { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Mail, ArrowUpRight, Facebook, Linkedin, Instagram, Twitter, CreditCard, Building2, X, Home } from 'lucide-react';
import AnimatedLogo from '../ui/AnimatedLogo';
import { createWaveCarveEffect } from '@/utils/animations/waveAnimations';
import { createWaveBounceEffect } from '@/utils/animations/sequenceAnimations';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';

interface WindowWithContactForm extends Window {
  openContactForm?: () => void;
}

declare global {
  interface Window {
    openContactForm?: () => void;
  }
}

const Footer = () => {
  const footerRef = useRef<HTMLElement>(null);
  const waveTextRef = useRef<HTMLDivElement>(null);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('opacity-100', 'translate-y-0');
          entry.target.classList.remove('opacity-0', 'translate-y-10');
        }
      });
    }, {
      root: null,
      rootMargin: '0px',
      threshold: 0.1
    });

    if (footerRef.current) {
      observer.observe(footerRef.current);
    }

    if (waveTextRef.current) {
      const text = "Thanks for visiting ZOGAGOVISUALS";
      waveTextRef.current.innerHTML = '';
      [...text].forEach((char, index) => {
        const span = document.createElement('span');
        span.textContent = char;
        span.className = 'inline-block transition-transform duration-300';
        span.style.animationDelay = `${index * 0.05}s`;
        waveTextRef.current?.appendChild(span);
      });

      const spans = waveTextRef.current.querySelectorAll('span');
      if (spans.length > 0) {
        createWaveBounceEffect(spans, {
          height: 12,
          duration: 0.8,
          stagger: 0.07,
          repeat: 0,
          delay: 0.2
        });
      }
    }

    // Add tilt effect to payment options
    const paymentItems = document.querySelectorAll('.payment-option');
    paymentItems.forEach(item => {
      item.addEventListener('mouseenter', handleTiltEnter);
      item.addEventListener('mouseleave', handleTiltLeave);
      item.addEventListener('mousemove', handleTiltMove);
    });

    function handleTiltEnter(e: Event) {
      const target = e.currentTarget as HTMLElement;
      target.style.transition = 'transform 0.2s ease-out';
    }

    function handleTiltLeave(e: Event) {
      const target = e.currentTarget as HTMLElement;
      target.style.transform = 'perspective(500px) rotateX(0) rotateY(0)';
      target.style.transition = 'transform 0.5s ease-out';
    }

    function handleTiltMove(e: MouseEvent) {
      const target = e.currentTarget as HTMLElement;
      const rect = target.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const tiltX = (y - centerY) / 10;
      const tiltY = (centerX - x) / 10;
      
      target.style.transform = `perspective(500px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) scale3d(1.05, 1.05, 1.05)`;
    }

    let cleanup: (() => void) | undefined;
    if (footerRef.current) {
      cleanup = createWaveCarveEffect(footerRef.current, "#1FB6FA");
    }

    return () => {
      if (footerRef.current) {
        observer.unobserve(footerRef.current);
      }
      
      paymentItems.forEach(item => {
        item.removeEventListener('mouseenter', handleTiltEnter);
        item.removeEventListener('mouseleave', handleTiltLeave);
        item.removeEventListener('mousemove', handleTiltMove);
      });
      
      if (cleanup) {
        cleanup();
      }
    };
  }, []);

  const openContactForm = () => {
    if (location.pathname !== '/') {
      navigate('/');
      setTimeout(() => {
        const contactSection = document.getElementById('contact');
        if (contactSection) {
          contactSection.scrollIntoView({
            behavior: 'smooth'
          });
        }
      }, 100);
    } else {
      const windowWithContactForm = window as WindowWithContactForm;
      if (typeof windowWithContactForm.openContactForm === 'function') {
        windowWithContactForm.openContactForm();
      }
    }
  };

  return <footer id="footer" ref={footerRef} className="border-t border-white/10 bg-gradient-to-b from-transparent to-black/20 pt-16 pb-8 opacity-0 translate-y-10 transition-all duration-1000 relative overflow-hidden">
      <div className="zg-container">
        <div className="flex justify-center mb-12">
          <Link to="/" className="hover:scale-105 transition-transform duration-300">
            <div className="w-[100px] h-[100px] logo-spin">
              <img src="/lovable-uploads/da6992de-0fc0-4a16-9851-7e1fa8680425.png" alt="Zogago Logo" className="w-full h-full object-contain" />
            </div>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-12">
          {/* Contact information column */}
          <div className="flex flex-col items-center md:items-start">
            <h3 className="text-xl font-bold text-gradient-blue mb-6 text-center md:text-left">Contact Us</h3>
            
            <div className="flex flex-col items-center md:items-start gap-4 mt-4">
              <div className="flex items-center space-x-2 text-zogago-light/80 hover:text-zogago-blue transition-colors group">
                <Mail className="w-5 h-5 group-hover:rotate-12 transition-transform duration-300" />
                <a href="mailto:contact@zogagovisuals.com" className="text-lg group-hover:scale-105 transition-transform duration-300">
                  contact@zogagovisuals.com
                </a>
              </div>
              
              <div className="flex justify-center md:justify-start gap-4 mt-2">
                <a href="https://www.facebook.com/profile.php?id=61574806213572" target="_blank" rel="noopener noreferrer" className="text-zogago-light/80 hover:text-zogago-blue transition-all duration-300 p-2 rounded-full hover:bg-[#11B3EEE6]/20 hover:scale-110">
                  <Facebook size={20} className="transition-transform duration-300 hover:rotate-12" />
                </a>
                <a href="https://www.linkedin.com/in/zogago-6b2009358?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" target="_blank" rel="noopener noreferrer" className="text-zogago-light/80 hover:text-zogago-blue transition-all duration-300 p-2 rounded-full hover:bg-[#11B3EEE6]/20 hover:scale-110">
                  <Linkedin size={20} className="transition-transform duration-300 hover:rotate-12" />
                </a>
                <a href="https://www.instagram.com/zogagovisuals/" target="_blank" rel="noopener noreferrer" className="text-zogago-light/80 hover:text-zogago-blue transition-all duration-300 p-2 rounded-full hover:bg-[#11B3EEE6]/20 hover:scale-110">
                  <Instagram size={20} className="transition-transform duration-300 hover:rotate-12" />
                </a>
                <a href="https://x.com/zogagovisuals?s=03" target="_blank" rel="noopener noreferrer" className="text-zogago-light/80 hover:text-zogago-blue transition-all duration-300 p-2 rounded-full hover:bg-[#11B3EEE6]/20 hover:scale-110">
                  <Twitter size={20} className="transition-transform duration-300 hover:rotate-12" />
                </a>
              </div>
            </div>
          </div>
          
          {/* Quick links column */}
          <div className="flex flex-col items-center md:items-start">
            <h3 className="text-xl font-bold text-gradient-blue mb-6 text-center md:text-left">Quick Links</h3>
            <div className="grid grid-cols-2 gap-x-8 gap-y-3">
              <Link to="/" className="relative text-zogago-light/80 hover:text-zogago-blue transition-colors duration-300 after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-0.5 after:bottom-0 after:left-0 after:bg-zogago-blue after:origin-bottom-right after:transition-transform after:duration-300 hover:after:scale-x-100 hover:after:origin-bottom-left">
                Home
              </Link>
              <Link to="/#about" className="relative text-zogago-light/80 hover:text-zogago-blue transition-colors duration-300 after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-0.5 after:bottom-0 after:left-0 after:bg-zogago-blue after:origin-bottom-right after:transition-transform after:duration-300 hover:after:scale-x-100 hover:after:origin-bottom-left">
                About
              </Link>
              <Link to="/#services" className="relative text-zogago-light/80 hover:text-zogago-blue transition-colors duration-300 after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-0.5 after:bottom-0 after:left-0 after:bg-zogago-blue after:origin-bottom-right after:transition-transform after:duration-300 hover:after:scale-x-100 hover:after:origin-bottom-left">
                Services
              </Link>
              <a href="#reviews" className="relative text-zogago-light/80 hover:text-zogago-blue transition-colors duration-300 after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-0.5 after:bottom-0 after:left-0 after:bg-zogago-blue after:origin-bottom-right after:transition-transform after:duration-300 hover:after:scale-x-100 hover:after:origin-bottom-left">
                Reviews
              </a>
              <Link to="/case-studies" className="relative text-zogago-light/80 hover:text-zogago-blue transition-colors duration-300 after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-0.5 after:bottom-0 after:left-0 after:bg-zogago-blue after:origin-bottom-right after:transition-transform after:duration-300 hover:after:scale-x-100 hover:after:origin-bottom-left">
                Case Studies
              </Link>
              <Link to="/privacy-policy" className="relative text-zogago-light/80 hover:text-zogago-blue transition-colors duration-300 after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-0.5 after:bottom-0 after:left-0 after:bg-zogago-blue after:origin-bottom-right after:transition-transform after:duration-300 hover:after:scale-x-100 hover:after:origin-bottom-left">
                Privacy Policy
              </Link>
              <Link to="/terms-and-conditions" className="relative text-zogago-light/80 hover:text-zogago-blue transition-colors duration-300 after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-0.5 after:bottom-0 after:left-0 after:bg-zogago-blue after:origin-bottom-right after:transition-transform after:duration-300 hover:after:scale-x-100 hover:after:origin-bottom-left">
                Terms & Conditions
              </Link>
            </div>
            
            <Button onClick={openContactForm} className="button-glow mt-8 transition-transform duration-300 hover:scale-105">
              <span className="relative z-10 flex items-center">
                Contact Us Today
                <ArrowUpRight className="ml-2 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform duration-300" />
              </span>
            </Button>
          </div>
          
          {/* Payment methods column */}
          <div className="flex flex-col items-center md:items-start">
            <h3 className="text-xl font-bold text-gradient-blue mb-6 text-center md:text-left">We Accept</h3>
            <div className="grid grid-cols-4 gap-4">
              <div className="payment-option flex flex-col items-center text-zogago-light/70 hover:text-zogago-blue transition-colors cursor-pointer">
                <img src="/lovable-uploads/ac977f5c-0fc3-4018-8f3b-379894ffe364.png" alt="Credit Card" className="h-8 w-auto mb-1 object-contain" />
                <span className="text-xs">Card</span>
              </div>
              <div className="payment-option flex flex-col items-center text-zogago-light/70 hover:text-zogago-blue transition-colors cursor-pointer">
                <img src="/lovable-uploads/93608a72-b8c2-4a4b-8838-5d4aed9a11bd.png" alt="Bitcoin" className="h-8 w-8 mb-1 object-contain" />
                <span className="text-xs">Bitcoin</span>
              </div>
              <div className="payment-option flex flex-col items-center text-zogago-light/70 hover:text-zogago-blue transition-colors cursor-pointer">
                <img src="/lovable-uploads/db3c9cd8-ddd4-45bc-be3f-eb4afcdab213.png" alt="USDT" className="h-8 w-8 mb-1 object-contain" />
                <span className="text-xs">USDT</span>
              </div>
              <div className="payment-option flex flex-col items-center text-zogago-light/70 hover:text-zogago-blue transition-colors cursor-pointer">
                <img src="/lovable-uploads/1c4e731d-8906-4ab7-b955-da4f2f2d816c.png" alt="Ethereum" className="h-8 w-8 mb-1 object-contain" />
                <span className="text-xs">ETH</span>
              </div>
              <div className="payment-option flex flex-col items-center text-zogago-light/70 hover:text-zogago-blue transition-colors cursor-pointer">
                <img src="/lovable-uploads/e6642539-98f6-4f65-942b-bb7fa012c989.png" alt="Solana" className="h-8 w-8 mb-1 object-contain" />
                <span className="text-xs">SOL</span>
              </div>
              <div className="payment-option flex flex-col items-center text-zogago-light/70 hover:text-zogago-blue transition-colors cursor-pointer">
                <img src="/lovable-uploads/b1d6bec8-78f1-4e44-9478-81129dfcf0bc.png" alt="Skrill" className="h-8 w-8 mb-1 object-contain" />
                <span className="text-xs">Skrill</span>
              </div>
              <div className="payment-option flex flex-col items-center text-zogago-light/70 hover:text-zogago-blue transition-colors cursor-pointer">
                <img src="/lovable-uploads/a7f59b0b-610e-4349-911b-0744025cf9cf.png" alt="Bank" className="h-8 w-8 mb-1 object-contain" />
                <span className="text-xs">Bank</span>
              </div>
              <div className="payment-option flex flex-col items-center text-zogago-light/70 hover:text-zogago-blue transition-colors cursor-pointer">
                <img src="/lovable-uploads/dc67f022-0fef-4253-968c-80a9d4a05bf7.png" alt="PayPal" className="h-8 w-8 mb-1 object-contain" />
                <span className="text-xs">PayPal</span>
              </div>
            </div>
          </div>
        </div>

        <div ref={waveTextRef} className="text-2xl font-bold text-gradient-blue mb-8 overflow-hidden text-center"></div>
        
        <Separator className="bg-white/10 my-6" />
        
        <div className="w-full pt-4">
          <p className="text-zogago-light/50 text-sm text-center">
            © 2024 ZOGAGOVISUALS. All rights reserved.
          </p>
        </div>
      </div>
    </footer>;
};

export default Footer;
