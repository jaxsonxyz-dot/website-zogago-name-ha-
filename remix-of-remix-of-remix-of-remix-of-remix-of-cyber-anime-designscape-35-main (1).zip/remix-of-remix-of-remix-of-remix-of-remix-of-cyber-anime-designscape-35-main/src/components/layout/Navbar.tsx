
import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ChevronRight, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useInView } from 'react-intersection-observer';
import AnimatedLogo from '../ui/AnimatedLogo';
import { scrollToElement } from '../../utils/scrollUtils';
import { useContactForm } from '@/hooks/useContactForm';
import ContactFormPopup from '../ui/ContactFormPopup';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);
  const lastScrollY = React.useRef(0);
  const {
    ref,
    inView
  } = useInView({
    threshold: 0.1,
    triggerOnce: true
  });
  const location = useLocation();
  const navigate = useNavigate();
  const { contactOpen, setContactOpen, geminiApiKey, setGeminiApiKey } = useContactForm();

  useEffect(() => {
    const handleScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 10);
      const delta = y - lastScrollY.current;
      if (y < 60 || isOpen) {
        setHidden(false);
      } else if (delta > 0 && y > 80) {
        setHidden(true);
      } else if (delta < -10) {
        setHidden(false);
      }
      if (Math.abs(delta) > 10 || y < 60) lastScrollY.current = y;
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isOpen]);

  const scrollToServices = (e: React.MouseEvent) => {
    e.preventDefault();
    
    if (location.pathname !== '/') {
      navigate('/', { state: { scrollToServices: true } });
    } else {
      const servicesSection = document.getElementById('services');
      if (servicesSection) {
        servicesSection.scrollIntoView({
          behavior: 'smooth'
        });
      }
    }
    setIsOpen(false);
  };

  const scrollToReviews = (e: React.MouseEvent) => {
    e.preventDefault();
    
    if (location.pathname !== '/') {
      navigate('/', { state: { scrollToReviews: true } });
    } else {
      const reviewsSection = document.getElementById('reviews');
      if (reviewsSection) {
        reviewsSection.scrollIntoView({
          behavior: 'smooth'
        });
      }
    }
    setIsOpen(false);
  };
  
  const handleGetStarted = () => {
    setContactOpen(true);
    setIsOpen(false);
  };

  useEffect(() => {
    if (location.pathname === '/' && location.state) {
      window.history.replaceState({}, document.title);
      setTimeout(() => {
        if (location.state.scrollToReviews) {
          const reviewsSection = document.getElementById('reviews');
          if (reviewsSection) {
            reviewsSection.scrollIntoView({
              behavior: 'smooth'
            });
          }
        } else if (location.state.scrollToServices) {
          const servicesSection = document.getElementById('services');
          if (servicesSection) {
            servicesSection.scrollIntoView({
              behavior: 'smooth'
            });
          }
        }
      }, 100);
    }
  }, [location]);

  return (
    <>
      <header ref={ref} className={`py-3 ${scrolled ? 'bg-black/80 backdrop-blur-md shadow-md' : ''} ${hidden ? '-translate-y-full opacity-0' : 'translate-y-0 opacity-100'} fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out`}>
        <div className="container mx-auto px-2">
          <div className="flex justify-between items-center">
            <Link to="/" className="z-50 flex items-center">
              <div className="w-[97px] h-[97px] logo-spin">
                <img src="/lovable-uploads/da6992de-0fc0-4a16-9851-7e1fa8680425.png" alt="Zogago Logo" className="w-full h-full object-contain" />
              </div>
            </Link>

            <div className="hidden md:flex items-center space-x-6">
              <Link to="/" className="text-white hover:text-primary transition-colors">
                Home
              </Link>
              <a href="#services" onClick={scrollToServices} className="text-white hover:text-primary transition-colors">
                Services
              </a>
              <Link to="/case-studies" className="text-white hover:text-primary transition-colors">
                Case Studies
              </Link>
              <Link to="/about" className="text-white hover:text-primary transition-colors">
                About
              </Link>
              <a href="#reviews" onClick={scrollToReviews} className="text-white hover:text-primary transition-colors">
                Reviews
              </a>
              
              {/* Get Started button */}
              <Button 
                onClick={handleGetStarted}
                className="button-glow transition-all duration-300"
              >
                <span>Get Started</span>
              </Button>
            </div>

            <div className="md:hidden flex items-center">
              <Button variant="ghost" size="icon" aria-label="Menu" onClick={() => setIsOpen(!isOpen)} className="text-white">
                {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>

        <AnimatePresence>
          {isOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.2 }}
              className="absolute top-full left-0 right-0 bg-black/90 backdrop-blur-md py-6 px-4 md:hidden"
            >
              <div className="flex flex-col space-y-4">
                <Link to="/" className="text-white hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>
                  Home
                </Link>
                <a href="#services" className="text-white hover:text-primary transition-colors" onClick={scrollToServices}>
                  Services
                </a>
                <Link to="/case-studies" className="text-white hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>
                  Case Studies
                </Link>
                <Link to="/about" className="text-white hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>
                  About
                </Link>
                <a href="#reviews" className="text-white hover:text-primary transition-colors" onClick={scrollToReviews}>
                  Reviews
                </a>
                
                {/* Get Started button in mobile menu */}
                <Button 
                  onClick={handleGetStarted}
                  className="button-glow w-full"
                >
                  <span>Get Started</span>
                </Button>
                
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Contact Form Popup */}
      <ContactFormPopup 
        open={contactOpen} 
        onOpenChange={setContactOpen} 
        geminiApiKey={geminiApiKey}
        onApiKeyChange={setGeminiApiKey}
      />
    </>
  );
};

export default Navbar;
