
import React, { useState } from 'react';
import Navbar from '../layout/Navbar';
import Footer from '../layout/Footer';
import ServiceShowcase from './ServiceShowcase';
import ServiceHero from './ServiceHero';
import { Separator } from '@/components/ui/separator';
import { motion } from 'framer-motion';
import ServiceProcessSection from './ServiceProcessSection';
import ServiceBenefitsSection, { BenefitFlipCard } from './ServiceBenefitsSection';
import ServiceRelatedCaseStudies from './ServiceRelatedCaseStudies';
import ServiceCTASection from './ServiceCTASection';
import ServiceGalleryDialog from './ServiceGalleryDialog';
import ServiceWorkTemplate from './ServiceWorkTemplate';
import { ProcessStep, BenefitItem, ServiceItem } from '@/types/services';

interface ServicesPageTemplateProps {
  pageTitle: string;
  pageDescription: string;
  galleryImages: string[];
  services: ServiceItem[];
  processSteps: ProcessStep[];
  benefits: BenefitItem[];
  flipCards?: BenefitFlipCard[];
  ctaTitle: string;
  ctaSubtitle: string;
  ctaGallery?: string[];
  workSectionTitle?: string;
  backgroundColor?: string;
}

const ServicesPageTemplate: React.FC<ServicesPageTemplateProps> = ({
  pageTitle,
  pageDescription,
  galleryImages,
  services,
  processSteps,
  benefits,
  flipCards,
  ctaTitle,
  ctaSubtitle,
  ctaGallery,
  workSectionTitle,
  backgroundColor = "from-zogago-blue to-zogago-purple"
}) => {
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  // Check if this is the SEO page
  const isSeoPage = pageTitle.toLowerCase().includes('seo');

  const openGallery = (images: string[]) => {
    setSelectedImages(images);
    setCurrentImageIndex(0);
    setIsGalleryOpen(true);
  };

  return (
    <>
      <Navbar />
      <div className="relative bg-zogago-dark">
        {/* Cyber Grid Convergence Hero */}
        <ServiceHero title={pageTitle} description={pageDescription}>
          {/* Gallery of images - only show for SEO page */}
          {isSeoPage && galleryImages.length > 0 && (
            <div className="grid grid-cols-5 gap-2 max-w-sm">
              {galleryImages.slice(0, 5).map((image, index) => (
                <div
                  key={index}
                  className="aspect-square rounded-sm overflow-hidden cursor-pointer hover:scale-105 transition-transform border border-zogago-light/10"
                  onClick={() => openGallery(galleryImages)}
                >
                  <img
                    src={image}
                    alt={`${pageTitle} ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          )}
        </ServiceHero>



        {/* Services Showcase / Portfolio */}
        <div id="services">
          <ServiceShowcase 
            title={`Our ${pageTitle} Services`}
            subtitle="Comprehensive solutions tailored for your business needs"
            services={services}
          />
        </div>

        {/* Benefits Section */}
        <ServiceBenefitsSection
          title={`Why Choose Our ${pageTitle} Services?`}
          subtitle="Partner with us for data-driven strategies that deliver measurable results"
          benefits={benefits}
          flipCards={flipCards}
        />

        {/* Related Case Studies — links the service portfolio to the case studies */}
        <ServiceRelatedCaseStudies pageTitle={pageTitle} />

        {/* CTA Section */}
        <ServiceCTASection
          title={ctaTitle}
          subtitle={ctaSubtitle}
        >
          {/* Image gallery - only show for SEO page */}
          {isSeoPage && (ctaGallery || galleryImages).length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 max-w-3xl mx-auto">
              {(ctaGallery || galleryImages).slice(0, 5).map((image, index) => (
                <div 
                  key={index}
                  className="aspect-square rounded-lg overflow-hidden cursor-pointer hover:scale-105 transition-transform"
                  onClick={() => openGallery(ctaGallery || galleryImages)}
                >
                  <img 
                    src={image} 
                    alt={`${pageTitle} Service ${index + 1}`} 
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          )}
        </ServiceCTASection>
        
        {/* Work Samples Section */}
        {workSectionTitle && (
          <section className="py-20">
            <div className="container mx-auto px-4">
              <Separator className="mb-20 bg-white/10" />
              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7 }}
                className="text-3xl md:text-4xl font-bold mb-4 text-center bg-clip-text text-transparent bg-gradient-to-r from-zogago-purple to-zogago-pink"
              >
                {workSectionTitle}
              </motion.h2>
            </div>
          </section>
        )}

        {/* Image Gallery Dialog - only for SEO page */}
        {isSeoPage && (
          <ServiceGalleryDialog
            isOpen={isGalleryOpen}
            onOpenChange={setIsGalleryOpen}
            images={selectedImages}
            currentImageIndex={currentImageIndex}
            setCurrentImageIndex={setCurrentImageIndex}
            title={pageTitle}
          />
        )}

        <Footer />
      </div>
    </>
  );
};

export default ServicesPageTemplate;
