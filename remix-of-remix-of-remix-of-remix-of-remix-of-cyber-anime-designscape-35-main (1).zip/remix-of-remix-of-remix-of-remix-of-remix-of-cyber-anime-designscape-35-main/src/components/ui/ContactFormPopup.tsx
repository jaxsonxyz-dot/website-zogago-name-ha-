import React, { useState, useRef, useEffect } from 'react';
import { X, Send, CheckCircle, ExternalLink, ArrowLeft, Sparkles, Wand2 } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import GlitchText from './GlitchText';
import { useToast } from "@/hooks/use-toast";
import { saveContactMessage } from '@/lib/storage';
import { Checkbox } from "@/components/ui/checkbox";
import { triggerConfetti } from '@/utils/animations/confettiAnimation';
import { ScrollArea } from "@/components/ui/scroll-area";
import { useGeminiAI } from '@/hooks/useGeminiAI';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
interface ContactFormPopupProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  geminiApiKey?: string;
  onApiKeyChange?: (key: string) => void;
}
const serviceOptions = [{
  id: 'webDevelopment',
  label: 'Web Development',
  shortLabel: 'Web Dev'
}, {
  id: 'graphicsDesign',
  label: 'Graphics Design',
  shortLabel: 'Graphics'
}, {
  id: 'socialMediaMarketing',
  label: 'Social Media Marketing',
  shortLabel: 'Social Media'
}, {
  id: 'seo',
  label: 'SEO',
  shortLabel: 'SEO'
}, {
  id: 'ecommerce',
  label: 'E-commerce',
  shortLabel: 'E-commerce'
}, {
  id: 'architecture',
  label: 'Architecture',
  shortLabel: 'Architecture'
}];
const ContactFormPopup: React.FC<ContactFormPopupProps> = ({
  open,
  onOpenChange,
  geminiApiKey = '',
  onApiKeyChange
}) => {
  const navigate = useNavigate();
  const {
    toast
  } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
    services: [] as string[]
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const successSoundRef = useRef<HTMLAudioElement | null>(null);
  const geminiAI = useGeminiAI();
  useEffect(() => {
    // Create audio element for success sound
    successSoundRef.current = new Audio('/success-sound.mp3');
    return () => {
      if (successSoundRef.current) {
        successSoundRef.current.pause();
        successSoundRef.current = null;
      }
    };
  }, []);
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const {
      name,
      value
    } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  const handleServiceToggle = (serviceId: string) => {
    setFormData(prev => {
      const services = prev.services.includes(serviceId) ? prev.services.filter(id => id !== serviceId) : [...prev.services, serviceId];
      return {
        ...prev,
        services
      };
    });
  };
  const playSuccessSound = () => {
    if (successSoundRef.current) {
      successSoundRef.current.currentTime = 0;
      successSoundRef.current.play().catch(e => console.log("Audio play error:", e));
    }
  };
  const handleExpandText = async () => {
    try {
      const expandedText = await geminiAI.expandText(formData.message);
      setFormData(prev => ({
        ...prev,
        message: expandedText
      }));
      toast({
        title: "Text Expanded",
        description: "Your message has been enhanced with AI assistance",
        duration: 1500
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to expand text",
        variant: "destructive",
        duration: 2000
      });
    }
  };
  const handleCorrectGrammar = async () => {
    try {
      const result = await geminiAI.correctGrammar(formData.message);
      if (!result.hasErrors) {
        toast({
          title: "Grammar Check Complete",
          description: "Your text is already grammatically correct!",
          duration: 1500
        });
        return;
      }
      setFormData(prev => ({
        ...prev,
        message: result.correctedText
      }));
      toast({
        title: "Grammar Corrected",
        description: "Your message has been proofread by AI",
        duration: 1500
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to correct grammar",
        variant: "destructive",
        duration: 2000
      });
    }
  };
  const handleSaveApiKey = () => {
    toast({
      title: "AI Ready",
      description: "AI features are powered by Lovable Cloud",
      duration: 2000
    });
  };
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!acceptTerms) {
      toast({
        title: "Error",
        description: "Please accept terms and conditions to continue",
        variant: "destructive",
        duration: 2000
      });
      return;
    }
    setIsSubmitting(true);

    // Save the contact message to storage
    saveContactMessage({
      name: formData.name,
      email: formData.email,
      message: formData.message,
      services: formData.services
    });

    // Show success notification with confetti
    toast({
      title: "Message sent!",
      description: `Thanks ${formData.name}! We'll be in touch soon.`,
      duration: 3000
    });

    // Play sound effect and trigger confetti
    playSuccessSound();
    triggerConfetti();

    // Close form after a short delay to let the user see the confetti
    setTimeout(() => {
      onOpenChange(false);

      // Reset form
      setIsSubmitting(false);
      setFormData({
        name: '',
        email: '',
        message: '',
        services: []
      });
      setAcceptTerms(false);

      // Navigate to thank you page
      navigate('/thank-you', {
        state: {
          name: formData.name
        },
        replace: true
      });
    }, 2000);
  };
  const handleBack = () => {
    onOpenChange(false);
  };
  return <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] bg-zogago-dark border border-white/10 text-zogago-light max-h-[90vh]">
        
        <ScrollArea className="h-[calc(90vh-80px)] pr-4">
          <div className="space-y-6">
            <div className="flex items-center justify-between pt-2">
              <h2 className="text-2xl font-bold">
                <GlitchText text="Contact Us" intensity="low" glitchInterval={8000} rgbShift={true} />
              </h2>
              
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-zogago-light/80 mb-1">
                    Name
                  </label>
                  <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-zogago-light focus:outline-none focus:ring-2 focus:ring-zogago-blue transition-all" placeholder="Your name" required />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-zogago-light/80 mb-1">
                    Email
                  </label>
                  <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-zogago-light focus:outline-none focus:ring-2 focus:ring-zogago-blue transition-all" placeholder="your.email@example.com" required />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-zogago-light/80 mb-2">
                    Services (Select all that apply)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {serviceOptions.map(service => <div key={service.id} onClick={() => handleServiceToggle(service.id)} className={`
                          flex items-center justify-center text-center px-2 py-2.5 rounded-md cursor-pointer transition-all min-h-[44px]
                          ${formData.services.includes(service.id) ? 'bg-zogago-blue/20 border border-zogago-blue/50' : 'bg-white/5 border border-white/10 hover:bg-[#11B3EEE6]/20'}
                        `}>
                        <span className="text-xs leading-snug">{service.shortLabel}</span>
                      </div>)}
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label htmlFor="message" className="block text-sm font-medium text-zogago-light/80">
                      Message
                    </label>
                    
                    {geminiAI.hasApiKey && <div className="flex space-x-2">
                        <button type="button" onClick={handleExpandText} disabled={geminiAI.isProcessing || !formData.message} className="text-xs flex items-center py-1 px-2 rounded bg-zogago-blue/10 text-zogago-blue hover:bg-[#11B3EEE6]/20 disabled:opacity-50 disabled:cursor-not-allowed">
                          <Sparkles className="w-3 h-3 mr-1" />
                          Expand
                        </button>
                        <button type="button" onClick={handleCorrectGrammar} disabled={geminiAI.isProcessing || !formData.message} className="text-xs flex items-center py-1 px-2 rounded bg-zogago-blue/10 text-zogago-blue hover:bg-[#11B3EEE6]/20 disabled:opacity-50 disabled:cursor-not-allowed">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Fix Grammar
                        </button>
                      </div>}
                  </div>
                  <textarea id="message" name="message" value={formData.message} onChange={handleChange} rows={4} className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-zogago-light focus:outline-none focus:ring-2 focus:ring-zogago-blue transition-all" placeholder={geminiAI.isProcessing ? "Processing with AI..." : "Tell us about your project..."} required disabled={geminiAI.isProcessing} />
                </div>
                
                <div className="flex items-start space-x-2">
                  <Checkbox id="terms1" checked={acceptTerms} onCheckedChange={checked => setAcceptTerms(checked as boolean)} className="bg-white/10 border-white/20 mt-1" />
                  <div className="grid gap-1.5 leading-none">
                    <label htmlFor="terms1" className="text-sm font-medium text-zogago-light/80 leading-tight cursor-pointer">
                      I accept the 
                      <Link to="/terms-and-conditions" className="text-zogago-blue hover:text-zogago-blue/80 mx-1 underline">
                        Terms and Conditions
                      </Link>
                      and 
                      <Link to="/privacy-policy" className="text-zogago-blue hover:text-zogago-blue/80 mx-1 underline">
                        Privacy Policy
                      </Link>
                    </label>
                  </div>
                </div>
                
                <button type="submit" disabled={isSubmitting} className="button-glow w-full group mb-4">
                  <span className="relative z-10 flex items-center justify-center">
                    {isSubmitting ? "Sending..." : <>
                        Send Message
                        <Send className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                      </>}
                  </span>
                </button>
              </form>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>;
};
export default ContactFormPopup;