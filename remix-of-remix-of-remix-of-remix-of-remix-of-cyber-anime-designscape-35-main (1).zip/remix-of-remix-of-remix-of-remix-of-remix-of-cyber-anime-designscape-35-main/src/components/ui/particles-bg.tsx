"use client";

import { useEffect, useCallback } from "react";

const BASE_PARTICLES = 170;
const PUSH_PER_CLICK = 2;
const MAX_CLICK_GROUPS = 8;
const CLICK_THROTTLE_MS = 100;

export default function ParticlesComponent() {
  const initParticles = useCallback(() => {
    const oldCanvas = document.querySelector("#particles-js canvas");
    if (oldCanvas) oldCanvas.remove();

    // @ts-ignore
    if (window.pJSDom?.length > 0) {
      // @ts-ignore
      window.pJSDom.forEach((p: any) => p.pJS.fn.vendors.destroypJS());
      // @ts-ignore
      window.pJSDom = [];
    }

    // @ts-ignore
    window.particlesJS("particles-js", {
      particles: {
        number: { value: BASE_PARTICLES, density: { enable: true, value_area: 800 } },

        color: { value: "#00f5ff" },
        shape: { type: "circle", stroke: { width: 0.5, color: "#0096c7" } },
        opacity: {
          value: 0.7,
          random: true,
          anim: { enable: true, speed: 1, opacity_min: 0.3 },
        },
        size: {
          value: 3,
          random: true,
          anim: { enable: true, speed: 2, size_min: 1 },
        },
        line_linked: {
          enable: true,
          distance: 160,
          color: "#00d9ff",
          opacity: 0.4,
          width: 1.2,
        },
        move: {
          enable: true,
          speed: 3.5,
          random: false,
          straight: false,
          out_mode: "bounce",
          attract: { enable: true, rotateX: 600, rotateY: 1200 },
        },
      },
      interactivity: {
        detect_on: "canvas",
        events: {
          onhover: { enable: true, mode: "grab" },
          // Click particles are managed below so rapid clicks cannot create an
          // unbounded render queue inside particles.js.
          onclick: { enable: false, mode: "push" },
          resize: true,
        },
        modes: {
          grab: { distance: 250, line_linked: { opacity: 0.9 } },
          push: { particles_nb: PUSH_PER_CLICK },
          repulse: { distance: 180, duration: 0.4 },
        },
      },
      retina_detect: true,
    });
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const script = document.createElement("script");
    script.src = "https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js";
    script.async = true;
    document.body.appendChild(script);

    script.onload = () => {
      initParticles();
    };

    return () => {
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
      // @ts-ignore
      if (window.pJSDom?.length > 0) {
        // @ts-ignore
        window.pJSDom.forEach((p: any) => p.pJS.fn.vendors.destroypJS());
        // @ts-ignore
        window.pJSDom = [];
      }
    };
  }, [initParticles]);

  // Every click inside the hero always spawns two fresh particles at the
  // cursor. Extras beyond eight clicks' worth are trimmed from the oldest
  // click particles, so the net keeps responding to clicks without overload.
  // The listener lives on window because the hero content sits above the
  // canvas and would otherwise swallow the clicks.
  useEffect(() => {
    if (typeof window === "undefined") return;

    const container = document.getElementById("particles-js");
    if (!container) return;

    const MAX_EXTRAS = MAX_CLICK_GROUPS * PUSH_PER_CLICK;
    let extras = 0;
    let lastAcceptedClick = 0;

    const handleClick = (event: MouseEvent) => {
      const now = performance.now();
      if (now - lastAcceptedClick < CLICK_THROTTLE_MS) return;

      // @ts-ignore particles.js exposes its active instances globally.
      const instance = window.pJSDom?.find(
        (entry: any) => entry?.pJS?.canvas?.el?.parentElement === container,
      )?.pJS;
      if (!instance) return;

      const canvas = instance.canvas.el as HTMLCanvasElement;
      const bounds = canvas.getBoundingClientRect();

      // Only react to clicks that land inside the hero net area.
      if (
        event.clientX < bounds.left || event.clientX > bounds.right ||
        event.clientY < bounds.top || event.clientY > bounds.bottom
      ) return;

      lastAcceptedClick = now;
      const particles = instance.particles.array;

      // Trim the oldest click particles first so the two new ones always fit
      // under the cap. Oldest extras sit at (length - extras) ... length-1.
      const toRemove = Math.max(0, Math.min(extras, extras + PUSH_PER_CLICK - MAX_EXTRAS));
      if (toRemove > 0) {
        particles.splice(particles.length - extras, toRemove);
        extras -= toRemove;
      }

      // Always create the two new particles at the click point.
      const pixelRatio = instance.retina?.pxratio ?? 1;
      instance.fn.modes.pushParticles(PUSH_PER_CLICK, {
        pos_x: (event.clientX - bounds.left) * pixelRatio,
        pos_y: (event.clientY - bounds.top) * pixelRatio,
      });
      extras = Math.min(MAX_EXTRAS, extras + PUSH_PER_CLICK);
    };

    window.addEventListener("click", handleClick);
    return () => window.removeEventListener("click", handleClick);
  }, []);


  return (
    <div
      id="particles-js"
      className="absolute inset-0 z-[2]"
      style={{ pointerEvents: "auto" }}
    />
  );
}

