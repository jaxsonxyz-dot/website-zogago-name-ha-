
import { useState, useEffect } from 'react';

declare global {
  interface Window {
    openContactForm?: () => void;
  }
}

export const useContactForm = () => {
  const [contactOpen, setContactOpen] = useState(false);
  const [geminiApiKey, setGeminiApiKey] = useState<string>(
    localStorage.getItem('gemini-api-key') || ''
  );
  
  // Make contact form popup available globally via window object
  useEffect(() => {
    // Add a global function to open the contact form
    window.openContactForm = () => setContactOpen(true);
    
    // Clean up
    return () => {
      delete window.openContactForm;
    };
  }, []);

  const updateGeminiApiKey = (key: string) => {
    localStorage.setItem('gemini-api-key', key);
    setGeminiApiKey(key);
  };

  return {
    contactOpen,
    setContactOpen,
    geminiApiKey,
    setGeminiApiKey: updateGeminiApiKey
  };
};
