
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const useGeminiAI = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  
  const expandText = async (text: string): Promise<string> => {
    if (!text.trim()) return text;

    setIsProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('ai-text', {
        body: { text, action: 'expand' },
      });

      if (error) throw new Error(error.message || 'Failed to expand text');
      return data?.result || text;
    } catch (error) {
      console.error('Error expanding text:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  };

  const correctGrammar = async (text: string): Promise<{ correctedText: string; hasErrors: boolean }> => {
    if (!text.trim()) return { correctedText: text, hasErrors: false };
    
    setIsProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('ai-text', {
        body: { text, action: 'grammar' },
      });

      if (error) throw new Error(error.message || 'Failed to correct grammar');
      
      const correctedText = data?.result || text;
      const hasErrors = correctedText.trim() !== text.trim();
      return { correctedText, hasErrors };
    } catch (error) {
      console.error('Error correcting grammar:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  };

  return {
    expandText,
    correctGrammar,
    isProcessing,
    hasApiKey: true,
  };
};
