// Define the types
export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  message: string;
  timestamp: number;
  services?: string[]; // Add services as an optional property
}

export interface Review {
  id: string;
  name: string;
  initial: string;
  role: string;
  company: string;
  text: string;
  rating: number;
  bgColor: string;
  timestamp: number;
}

// Storage keys
const CONTACT_STORAGE_KEY = 'zogago_contact_messages';
const REVIEWS_STORAGE_KEY = 'zogago_reviews';
const REVIEWS_INITIALIZED_KEY = 'zogago_reviews_initialized';

// Generate a unique ID
const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// Contact Messages
export const saveContactMessage = (message: Omit<ContactMessage, 'id' | 'timestamp'>): ContactMessage => {
  const newMessage: ContactMessage = {
    ...message,
    id: generateId(),
    timestamp: Date.now(),
  };

  const existingMessages = getContactMessages();
  const updatedMessages = [...existingMessages, newMessage];
  
  localStorage.setItem(CONTACT_STORAGE_KEY, JSON.stringify(updatedMessages));
  
  console.log('Contact message saved:', newMessage);
  return newMessage;
};

export const getContactMessages = (): ContactMessage[] => {
  const messagesJson = localStorage.getItem(CONTACT_STORAGE_KEY);
  return messagesJson ? JSON.parse(messagesJson) : [];
};

// Default reviews data 
const defaultReviews: Review[] = [
  {
    id: 'default-1',
    name: "Alex Johnson",
    initial: "A",
    role: "Marketing Director",
    company: "TechGrowth Inc.",
    text: "ZOGAGO completely transformed our online presence. Their SEO strategies boosted our organic traffic by 200% in just three months. Highly recommended!",
    rating: 5,
    bgColor: "bg-zogago-blue",
    timestamp: Date.now() - 7 * 24 * 60 * 60 * 1000 // 7 days ago
  },
  {
    id: 'default-2',
    name: "Sarah Wong",
    initial: "S",
    role: "E-commerce Manager",
    company: "StyleFactory",
    text: "The e-commerce store they designed for us not only looks incredible but has increased our conversion rate by 45%. Their attention to detail is unmatched.",
    rating: 5,
    bgColor: "bg-zogago-purple",
    timestamp: Date.now() - 14 * 24 * 60 * 60 * 1000 // 14 days ago
  },
  {
    id: 'default-3',
    name: "Michael Chen",
    initial: "M",
    role: "Creative Director",
    company: "Pixel Studios",
    text: "The custom anime characters they created for our game were beyond our expectations. They perfectly captured our vision and delivered on time.",
    rating: 4,
    bgColor: "bg-zogago-pink",
    timestamp: Date.now() - 30 * 24 * 60 * 60 * 1000 // 30 days ago
  },
  {
    id: 'default-4',
    name: "Emily Rodriguez",
    initial: "E",
    role: "Content Creator",
    company: "VideoVerse",
    text: "Their thumbnail designs have significantly improved my click-through rates on YouTube. Professional, creative, and always responsive to feedback.",
    rating: 5,
    bgColor: "bg-blue-500",
    timestamp: Date.now() - 45 * 24 * 60 * 60 * 1000 // 45 days ago
  },
  {
    id: 'default-5',
    name: "David Thompson",
    initial: "D",
    role: "CTO",
    company: "Innovate Solutions",
    text: "The web application ZOGAGO developed for us streamlined our operations and saved us countless hours each month. Their technical expertise is outstanding.",
    rating: 5,
    bgColor: "bg-indigo-500",
    timestamp: Date.now() - 60 * 24 * 60 * 60 * 1000 // 60 days ago
  },
  {
    id: 'default-6',
    name: "Priya Patel",
    initial: "P",
    role: "Brand Manager",
    company: "Global Trends",
    text: "ZOGAGO's branding work completely revitalized our company image. Our customers love the new look, and we've seen a significant increase in brand recognition.",
    rating: 4,
    bgColor: "bg-violet-500",
    timestamp: Date.now() - 75 * 24 * 60 * 60 * 1000 // 75 days ago
  },
  {
    id: 'default-7',
    name: "James Wilson",
    initial: "J",
    role: "Product Owner",
    company: "NextGen Software",
    text: "Working with ZOGAGO on our app redesign was a fantastic experience. They understood our users' needs and delivered an intuitive, beautiful interface.",
    rating: 5,
    bgColor: "bg-zogago-blue",
    timestamp: Date.now() - 90 * 24 * 60 * 60 * 1000 // 90 days ago
  },
  {
    id: 'default-8',
    name: "Maria Sanchez",
    initial: "M",
    role: "Digital Strategist",
    company: "Future Media",
    text: "The SEO and content strategy ZOGAGO implemented has given us consistent growth month after month. Their data-driven approach really sets them apart.",
    rating: 5,
    bgColor: "bg-zogago-purple",
    timestamp: Date.now() - 105 * 24 * 60 * 60 * 1000 // 105 days ago
  }
];

// Get background color for reviews
export const getRandomBgColor = (): string => {
  const colors = [
    "bg-zogago-blue", 
    "bg-zogago-purple", 
    "bg-zogago-pink", 
    "bg-blue-500", 
    "bg-indigo-500", 
    "bg-violet-500"
  ];
  return colors[Math.floor(Math.random() * colors.length)];
};

// Initialize reviews if needed
const initializeReviews = (): void => {
  const initialized = localStorage.getItem(REVIEWS_INITIALIZED_KEY);
  if (!initialized) {
    localStorage.setItem(REVIEWS_STORAGE_KEY, JSON.stringify(defaultReviews));
    localStorage.setItem(REVIEWS_INITIALIZED_KEY, 'true');
  }
};

// Reviews
export const saveReview = (review: Omit<Review, 'id' | 'timestamp' | 'bgColor'>): Review => {
  // Ensure reviews are initialized
  initializeReviews();
  
  const newReview: Review = {
    ...review,
    id: generateId(),
    timestamp: Date.now(),
    bgColor: getRandomBgColor(),
  };

  // Get existing reviews
  const existingReviews = getReviews();
  
  // Add the new review
  const updatedReviews = [...existingReviews, newReview];
  
  localStorage.setItem(REVIEWS_STORAGE_KEY, JSON.stringify(updatedReviews));
  
  console.log('Review saved:', newReview);
  return newReview;
};

export const getReviews = (): Review[] => {
  // Ensure reviews are initialized
  initializeReviews();
  
  const reviewsJson = localStorage.getItem(REVIEWS_STORAGE_KEY);
  
  if (!reviewsJson) {
    return [];
  }
  
  return JSON.parse(reviewsJson);
};

// Get all reviews sorted by timestamp (newest first)
export const getAllReviews = (): Review[] => {
  const storedReviews = getReviews();
  
  // Sort reviews by timestamp, most recent first
  return storedReviews.sort((a, b) => b.timestamp - a.timestamp);
};
