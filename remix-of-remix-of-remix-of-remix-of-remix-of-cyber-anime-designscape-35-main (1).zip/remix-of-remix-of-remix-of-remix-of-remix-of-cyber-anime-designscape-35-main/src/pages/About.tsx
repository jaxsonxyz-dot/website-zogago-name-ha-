
import React from 'react';
import Navbar from '../components/layout/Navbar';
import Footer from '../components/layout/Footer';
import AboutSection from '../components/home/About';

const About = () => {
  return (
    <div className="min-h-screen bg-zogago-dark text-zogago-light flex flex-col">
      <Navbar />
      <main className="flex-grow pt-24">
        <div className="container mx-auto px-4">
          <div className="py-8">
            <h1 className="text-4xl font-bold text-gradient-blue mb-8">About Us</h1>
          </div>
        </div>
        <AboutSection />
      </main>
      <Footer />
    </div>
  );
};

export default About;
