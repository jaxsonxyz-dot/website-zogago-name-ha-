import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import CaseStudyCard from '@/components/casestudies/CaseStudyCard';
import { caseStudies, caseStudyCategories, CaseStudyCategory } from '@/data/caseStudies';

type Filter = 'All' | CaseStudyCategory;

const filters: Filter[] = ['All', ...caseStudyCategories];

const CaseStudies: React.FC = () => {
  const [active, setActive] = useState<Filter>('All');

  const visible = useMemo(
    () => (active === 'All' ? caseStudies : caseStudies.filter((c) => c.category === active)),
    [active],
  );

  return (
    <div className="min-h-screen bg-zogago-dark text-zogago-light">
      <Navbar />

      <main className="pt-28 md:pt-[150px] pb-16 md:pb-24">
        <section className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-zogago-blue to-zogago-purple">
              CASE STUDIES
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-lg text-zogago-light/70">
              Selected work, creative process, and design solutions.
            </p>
          </motion.div>

          <div className="mt-8 md:mt-12 flex overflow-x-auto sm:flex-wrap justify-start sm:justify-center gap-2 md:gap-3 px-4 -mx-4 sm:mx-0 sm:px-0 py-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setActive(f)}
                className={`whitespace-nowrap flex-shrink-0 rounded-full border px-3.5 py-1.5 text-xs sm:px-5 sm:py-2 sm:text-sm transition-all duration-300 ${
                  active === f
                    ? 'border-zogago-blue/60 bg-zogago-blue/10 text-white shadow-[0_0_25px_-8px_rgba(31,182,250,0.7)]'
                    : 'border-white/10 text-zogago-light/60 hover:border-zogago-blue/40 hover:text-white'
                }`}
              >
                {f}
              </button>
            ))}
          </div>

          <motion.div layout className="mt-8 md:mt-14 grid gap-5 md:gap-8 sm:grid-cols-2 lg:grid-cols-3">
            <AnimatePresence mode="popLayout">
              {visible.map((study) => (
                <motion.div
                  className="h-full"
                  key={study.slug}
                  layout
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -12 }}
                  transition={{ duration: 0.4, ease: 'easeOut' }}
                >
                  <CaseStudyCard study={study} />
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default CaseStudies;
