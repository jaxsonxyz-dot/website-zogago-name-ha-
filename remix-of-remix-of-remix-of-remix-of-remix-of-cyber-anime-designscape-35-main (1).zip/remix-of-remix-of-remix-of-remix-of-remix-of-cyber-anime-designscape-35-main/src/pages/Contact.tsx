
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Send, CheckCircle } from 'lucide-react';
import Navbar from '../components/layout/Navbar';
import Footer from '../components/layout/Footer';
import { useToast } from '@/hooks/use-toast';
import { saveContactMessage } from '@/lib/storage';

const Contact = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
    services: [] as string[]
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [acceptTerms, setAcceptTerms] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleServiceToggle = (serviceId: string) => {
    setFormData(prev => {
      const services = prev.services.includes(serviceId) 
        ? prev.services.filter(id => id !== serviceId) 
        : [...prev.services, serviceId];
      return { ...prev, services };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Save the contact message to storage
    saveContactMessage({
      name: formData.name,
      email: formData.email,
      message: formData.message,
      services: formData.services
    });

    // Show success notification
    toast({
      title: "Message sent!",
      description: `Thanks ${formData.name}! We'll be in touch soon.`,
      duration: 3000
    });

    // Reset form after a delay
    setTimeout(() => {
      setIsSubmitting(false);
      setFormData({
        name: '',
        email: '',
        message: '',
        services: []
      });
      setAcceptTerms(false);
    }, 2000);
  };

  const serviceOptions = [
    { id: 'webDevelopment', label: 'Web Development', shortLabel: 'Web Dev' },
    { id: 'graphicsDesign', label: 'Graphics Design', shortLabel: 'Graphics' },
    { id: 'socialMediaMarketing', label: 'Social Media Marketing', shortLabel: 'Social Media' },
    { id: 'seo', label: 'SEO', shortLabel: 'SEO' },
    { id: 'ecommerce', label: 'E-commerce', shortLabel: 'E-commerce' },
    { id: 'architecture', label: 'Architecture', shortLabel: 'Architecture' }
  ];

  return (
    <>
      <Navbar />
      <div className="relative min-h-screen bg-zogago-dark py-24">
        <div className="container mx-auto px-4">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center mb-12"
          >
            <h1 className="text-2xl sm:text-3xl md:text-5xl font-bold mb-2 sm:mb-4 bg-clip-text text-transparent bg-gradient-to-r from-zogago-blue to-zogago-purple">
              Contact Us
            </h1>
            <p className="text-sm sm:text-base md:text-lg text-zogago-light/70 max-w-3xl mx-auto px-2">
              Get in touch with our team for inquiries, collaborations, or to discuss your next project.
            </p>
          </motion.div>
          
          <div className="max-w-3xl mx-auto">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="glass-card p-4 sm:p-6 md:p-8 border border-white/10"
            >
              <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-zogago-light/80 mb-1">
                    Name
                  </label>
                  <input 
                    type="text" 
                    id="name" 
                    name="name" 
                    value={formData.name} 
                    onChange={handleChange} 
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-zogago-light focus:outline-none focus:ring-2 focus:ring-zogago-blue transition-all" 
                    placeholder="Your name" 
                    required 
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-zogago-light/80 mb-1">
                    Email
                  </label>
                  <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    value={formData.email} 
                    onChange={handleChange} 
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-zogago-light focus:outline-none focus:ring-2 focus:ring-zogago-blue transition-all" 
                    placeholder="your.email@example.com" 
                    required 
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-zogago-light/80 mb-2">
                    Services (Select all that apply)
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-2.5">
                    {serviceOptions.map(service => (
                      <div 
                        key={service.id} 
                        onClick={() => handleServiceToggle(service.id)} 
                        className={`
                          flex items-center justify-center text-center px-2 py-2.5 sm:px-2.5 sm:py-3 rounded-md cursor-pointer transition-all min-h-[44px]
                          ${formData.services.includes(service.id) 
                            ? 'bg-zogago-blue/20 border border-zogago-blue/50' 
                            : 'bg-white/5 border border-white/10 hover:bg-gradient-to-r hover:from-zogago-blue/20 hover:via-zogago-purple/20 hover:to-zogago-pink/20'}
                        `}
                      >
                        <span className="text-xs sm:text-sm leading-snug"><span className="sm:hidden">{service.shortLabel}</span><span className="hidden sm:inline">{service.label}</span></span>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-zogago-light/80 mb-1">
                    Message
                  </label>
                  <textarea 
                    id="message" 
                    name="message" 
                    value={formData.message} 
                    onChange={handleChange} 
                    rows={4} 
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-zogago-light focus:outline-none focus:ring-2 focus:ring-zogago-blue transition-all" 
                    placeholder="Tell us about your project..." 
                    required 
                  />
                </div>
                
                <div className="flex items-center space-x-2">
                  <input 
                    type="checkbox" 
                    id="terms" 
                    checked={acceptTerms}
                    onChange={() => setAcceptTerms(!acceptTerms)}
                    className="rounded bg-white/10 border-white/20"
                  />
                  <label htmlFor="terms" className="text-sm text-zogago-light/80">
                    I accept the Terms and Conditions and Privacy Policy
                  </label>
                </div>
                
                <Button 
                  type="submit" 
                  disabled={isSubmitting} 
                  className="button-glow w-full"
                >
                  <span className="flex items-center justify-center">
                    {isSubmitting ? "Sending..." : (
                      <>
                        Send Message
                        <Send className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </span>
                </Button>
              </form>
            </motion.div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Contact;
