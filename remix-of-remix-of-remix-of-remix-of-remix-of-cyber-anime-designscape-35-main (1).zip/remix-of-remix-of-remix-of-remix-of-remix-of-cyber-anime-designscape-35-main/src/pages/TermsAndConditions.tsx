
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';
import Navbar from '../components/layout/Navbar';
import Footer from '../components/layout/Footer';
import { Button } from '@/components/ui/button';

const TermsAndConditions = () => {
  // Scroll to top on component mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-zogago-dark text-zogago-light">
      <Navbar />
      
      <main className="pt-28 pb-20">
        <div className="zg-container">
          <div className="max-w-4xl mx-auto">
            <div className="flex justify-between items-center mb-8">
              <h1 className="zg-heading-xl">Terms and Conditions</h1>
              <Link to="/">
                <Button variant="outline" className="button-glow-outline flex items-center gap-2">
                  <Home size={18} />
                  Back to Home
                </Button>
              </Link>
            </div>
            
            <div className="space-y-6 text-zogago-light/90">
              <p>
                Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
              
              <section>
                <h2 className="text-2xl font-bold mb-4 text-zogago-blue">Transparency & Quality Service</h2>
                <p>
                  We are committed to providing clear communication, fair pricing, and high-quality graphic design services.
                  Our process ensures full transparency from initial discussions to project completion.
                </p>
              </section>
              
              <section>
                <h2 className="text-2xl font-bold mb-4 text-zogago-blue">Payment Policy</h2>
                <p>
                  A 50% upfront payment is required before work begins.
                  Clients may choose to pay the full amount upfront if preferred.
                  For larger projects, an initial payment of 30% may be accepted, depending on the project scope.
                </p>
              </section>
              
              <section>
                <h2 className="text-2xl font-bold mb-4 text-zogago-blue">Payment Methods</h2>
                <p>
                  We accept the following payment methods:
                </p>
                <div className="flex flex-wrap gap-4 my-4">
                  <div className="flex items-center gap-2">
                    <img src="/lovable-uploads/93608a72-b8c2-4a4b-8838-5d4aed9a11bd.png" alt="Bitcoin" className="h-5 w-5 object-contain" />
                    <span>Bitcoin</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <img src="/lovable-uploads/963e0c1b-b113-4286-a6dd-0f2dfce14740.png" alt="Ethereum" className="h-5 w-5 object-contain" />
                    <span>Ethereum</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <img src="/lovable-uploads/e6642539-98f6-4f65-942b-bb7fa012c989.png" alt="Solana" className="h-5 w-5 object-contain" />
                    <span>Solana</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <img src="/lovable-uploads/db3c9cd8-ddd4-45bc-be3f-eb4afcdab213.png" alt="USDT" className="h-5 w-5 object-contain" />
                    <span>USDT</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <img src="/lovable-uploads/0dbb71d6-7cce-4191-bf82-7a893fc103bb.png" alt="Skrill" className="h-5 w-5 object-contain" />
                    <span>Skrill</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <img src="/lovable-uploads/adbb332a-9714-4b21-b4cb-bcb999329e8f.png" alt="Bank Transfer" className="h-5 w-5 object-contain" />
                    <span>Bank Transfer</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <img src="/lovable-uploads/6cc18300-bb59-4d06-9973-e7cbbb875547.png" alt="Credit Card" className="h-5 w-5 object-contain" />
                    <span>Credit Card</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <img src="/lovable-uploads/dc67f022-0fef-4253-968c-80a9d4a05bf7.png" alt="PayPal" className="h-5 w-5 object-contain" />
                    <span>PayPal</span>
                  </div>
                </div>
                <p>
                  We highly recommend cryptocurrency payments for faster processing and enhanced security.
                </p>
              </section>
              
              <section>
                <h2 className="text-2xl font-bold mb-4 text-zogago-blue">Order Process</h2>
                <p>
                  All project discussions and inquiries must be sent via email or through the Contact Us page on our website.
                  Our team will review and respond promptly before confirming your order.
                </p>
              </section>
              
              <section>
                <h2 className="text-2xl font-bold mb-4 text-zogago-blue">Project Timeline & Revisions</h2>
                <p>
                  A clear time frame will be provided before starting the project.
                  After final delivery, additional revisions will be charged at $20 per revision.
                  Clients must communicate all requirements before placing an order to avoid unnecessary revisions.
                </p>
              </section>
              
              <section>
                <h2 className="text-2xl font-bold mb-4 text-zogago-blue">Payment Verification</h2>
                <p>
                  Payments are typically verified instantly or within an hour. If verification is delayed, it may take up to 3 days.
                  If the payment is not received within 3 days, we will contact you for further clarification.
                  We highly recommend using cryptocurrency (BTC, USDT, SOL, ETH, and Skrill) for faster and more secure transactions without delays or scams.
                </p>
              </section>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default TermsAndConditions;
