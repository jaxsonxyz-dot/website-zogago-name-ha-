import React from 'react';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import CaseStudy, { CaseStudyData } from '@/components/portfolio/CaseStudy';

const demoData: CaseStudyData = {
  projectName: 'Neon Commerce Rebrand',
  summary:
    'A complete redesign and rebuild of an e-commerce storefront, focused on bold visuals, friction-free checkout, and a brand system that scales across every touchpoint.',
  heroImage: '/lovable-uploads/706fb2be-91c5-4f4e-bfc3-1a4450773135.png',
  client: 'Neon Commerce',
  industry: 'E-commerce / Retail',
  timeline: '8 Weeks — 2026',
  services: 'UI/UX Design, Web Development, Branding',
  challenge:
    'The existing store suffered from an outdated interface, slow page loads, and a confusing checkout flow. Cart abandonment was high and the brand lacked a consistent visual identity across devices.',
  solution:
    'We rebuilt the storefront with a performance-first architecture, introduced a bold neon design system, and streamlined checkout into a single guided flow — lifting checkout conversion by 40%.',
  screens: [
    {
      tag: 'Primary Screen',
      title: 'Immersive Homepage Experience',
      description:
        'A hero-driven layout with animated product showcases and clear calls-to-action that guide visitors straight into the catalog.',
      image: '/lovable-uploads/6f572f13-a17a-4036-ba2b-c2222a953e91.png',
    },
    {
      tag: 'Key Page',
      title: 'Conversion-Focused Product Pages',
      description:
        'Rich imagery, sticky add-to-cart, and social proof placed exactly where buying decisions happen.',
      image: '/lovable-uploads/93608a72-b8c2-4a4b-8838-5d4aed9a11bd.png',
    },
    {
      tag: 'Interactive Workflow',
      title: 'One-Page Guided Checkout',
      description:
        'A distraction-free, step-by-step checkout with inline validation and multiple payment options — the core of the conversion lift.',
      image: '/lovable-uploads/af39ed02-5dd9-47e0-8743-fc98059cf9f9.png',
    },
  ],
  backLink: '/#portfolio',
  backLabel: 'Back to Portfolio',
};

const CaseStudyDemo: React.FC = () => {
  return (
    <>
      <Navbar />
      <CaseStudy data={demoData} />
      <Footer />
    </>
  );
};

export default CaseStudyDemo;
