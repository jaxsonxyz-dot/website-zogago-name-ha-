import React from 'react';
import { Compass, Target, Map, Lightbulb, Users, TrendingUp, MessageSquare, Search, Award, Sparkles } from 'lucide-react';
import ServicesPageTemplate from '../../components/services/ServicesPageTemplate';
import { createStandardProcessSteps, graphicsFlipCards } from '@/data/standardProcessSteps';
import { BenefitFlipCard } from '@/components/services/ServiceBenefitsSection';

const brandStrategyProcessSteps = createStandardProcessSteps(graphicsFlipCards);

const brandStrategyServices = [{
  id: 1,
  title: "Brand Positioning",
  description: "Define where your brand sits in the market and why customers should choose you over anyone else.",
  imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80&w=2070",
  route: "/contact",
  galleryImages: ["https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80&w=2070"]
}, {
  id: 2,
  title: "Messaging & Voice",
  description: "Craft a clear, consistent brand voice and messaging framework that resonates with your audience.",
  imageUrl: "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&q=80&w=2074",
  route: "/contact",
  galleryImages: ["https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&q=80&w=2074"]
}, {
  id: 3,
  title: "Brand Roadmaps",
  description: "Actionable launch and growth roadmaps that turn strategy into measurable momentum.",
  imageUrl: "https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&q=80&w=2070",
  route: "/contact",
  galleryImages: ["https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&q=80&w=2070"]
}];

const brandStrategyFlipCards: BenefitFlipCard[] = [{
  title: "Clear Direction",
  subtitle: "Know your lane",
  description: "A defined positioning and roadmap so every decision — design, content, marketing — moves in one direction.",
  features: ['Market Analysis', 'Competitor Research', 'Positioning', 'Differentiation'],
  frontIcon: Compass,
  featureIcons: [Search, Target, Map, TrendingUp],
  color: "#0EA5E9"
}, {
  title: "Audience Connection",
  subtitle: "Speak their language",
  description: "Messaging built on real audience insight, so your brand connects emotionally and converts consistently.",
  features: ['Audience Personas', 'Brand Voice', 'Story Framework', 'Key Messages'],
  frontIcon: Users,
  featureIcons: [Users, MessageSquare, Lightbulb, Sparkles],
  color: "#8B5CF6"
}, {
  title: "Lasting Advantage",
  subtitle: "Built to endure",
  description: "Strategy that outlives trends — a brand foundation strong enough to grow on for years.",
  features: ['Brand Architecture', 'Growth Roadmap', 'Launch Planning', 'Measurement'],
  frontIcon: Award,
  featureIcons: [Award, Map, TrendingUp, Target],
  color: "#EC4899"
}];

const BrandStrategy = () => {
  return (
    <div className="min-h-screen bg-zogago-dark">
      <ServicesPageTemplate
        pageTitle="Brand Strategy"
        pageDescription="Positioning, messaging, and roadmaps that give your brand clear direction — so every design, campaign, and decision moves you forward."
        galleryImages={[]}
        services={brandStrategyServices}
        processSteps={brandStrategyProcessSteps}
        benefits={[]}
        flipCards={brandStrategyFlipCards}
        ctaTitle="Ready to Give Your Brand Clear Direction?"
        ctaSubtitle="Let's build a strategy that turns your vision into a brand people remember."
        workSectionTitle="Our Brand Strategy Work"
      />
    </div>
  );
};

export default BrandStrategy;
