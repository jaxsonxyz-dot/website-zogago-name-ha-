import React from 'react';
import { Palette, Brush, Image, Layers, Pen, Eye, Sparkles, Paintbrush, Shapes, Star, Wand2 } from 'lucide-react';
import ServicesPageTemplate from '../../components/services/ServicesPageTemplate';
import { createStandardProcessSteps, graphicsFlipCards } from '@/data/standardProcessSteps';
import { BenefitFlipCard } from '@/components/services/ServiceBenefitsSection';
import logoBeautyCosmetics from '@/assets/logos/logo-beauty-cosmetics.png.asset.json';
import logoRestaurant from '@/assets/logos/logo-restaurant-nobg.png';
import logoPremium from '@/assets/logos/logo-premium-nature.png.asset.json';
import logoHomeDecorators from '@/assets/logos/logo-home-decorators-v2.png.asset.json';
import logoCyberSecurity from '@/assets/logos/logo-cyber-security.png.asset.json';
import logo3dGym from '@/assets/logos/logo-3d-gym.png.asset.json';
import logoAegisMedia from '@/assets/logos/logo-aegis-media.jpg.asset.json';
import logoPopCulture from '@/assets/logos/logo-pop-culture.jpg.asset.json';
import logoChronos from '@/assets/logos/logo-chronos-aesthetics.png.asset.json';
import logoMrVision from '@/assets/logos/logo-mr-vision.png.asset.json';

const graphicsDesignProcessSteps = createStandardProcessSteps(graphicsFlipCards);

// Custom logo portfolio — real client logo designs
const logoPortfolioItems = [
  { src: logoBeautyCosmetics.url, title: "B Beauty Cosmetics", caseStudyRoute: "/case-studies/logo-project-02" },
  { src: logoRestaurant, title: "Good Food • Good Mood", caseStudyRoute: "/case-studies/logo-project-07" },
  { src: logoPremium.url, title: "Premium by Nature", caseStudyRoute: "/case-studies/logo-project-08" },
  { src: logoHomeDecorators.url, title: "Home Decorators", caseStudyRoute: "/case-studies/logo-project-06" },
  { src: logoCyberSecurity.url, title: "Cyber Security" },
  { src: logo3dGym.url, title: "3D Gym", caseStudyRoute: "/case-studies/logo-project-01" },
  { src: logoAegisMedia.url, title: "Aegis Media" },
  { src: logoPopCulture.url, title: "Pop Culture", caseStudyRoute: "/case-studies/logo-project-03" },
  { src: logoChronos.url, title: "Chronos Aesthetics", caseStudyRoute: "/case-studies/logo-project-05" },
  { src: logoMrVision.url, title: "MR VISION", caseStudyRoute: "/case-studies/logo-project-04" },
];
const logoPortfolioImages = logoPortfolioItems.map((i) => i.src);


const graphicsDesignServices = [{
  id: 1,
  title: "Brand Identity Design",
  description: "Complete brand identity systems including logos, color palettes, typography, and brand guidelines.",
  imageUrl: "https://images.unsplash.com/photo-1572044162444-ad60f128bdea?auto=format&fit=crop&q=80&w=2070",
  route: "/contact",
  galleryImages: logoPortfolioImages,
  galleryItems: logoPortfolioItems,
  caseStudyRoute: "/case-studies/logo-project-01",
  caseStudyLabel: "View Branding Work →"
}, {
  id: 2,
  title: "Digital Marketing Graphics",
  description: "Eye-catching graphics for social media, ads, email campaigns, and other digital marketing channels.",
  imageUrl: "https://images.unsplash.com/photo-1560036013-a21b18b02c63?auto=format&fit=crop&q=80&w=2070",
  route: "/contact",
  galleryImages: ["https://images.unsplash.com/photo-1560036013-a21b18b02c63?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1574887427561-d3d5d58c9273?auto=format&fit=crop&q=80&w=1976", "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?auto=format&fit=crop&q=80&w=1974", "https://images.unsplash.com/photo-1558655146-9f40138edfeb?auto=format&fit=crop&q=80&w=2070"]
}, {
  id: 3,
  title: "Print Design & Packaging",
  description: "High-quality print materials and product packaging designs that make your brand stand out.",
  imageUrl: "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?auto=format&fit=crop&q=80&w=2070",
  route: "/contact",
  galleryImages: ["https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1574887427561-d3d5d58c9273?auto=format&fit=crop&q=80&w=1976", "https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&q=80&w=2071", "https://images.unsplash.com/photo-1572044162444-ad60f128bdea?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1560036013-a21b18b02c63?auto=format&fit=crop&q=80&w=2070"]
}];

const graphicsFlipCardBenefits: BenefitFlipCard[] = [{
  title: "Visual Brand Consistency",
  subtitle: "Cohesive identity",
  description: "Create a cohesive visual identity across all touchpoints to strengthen brand recognition and trust.",
  features: ['Brand Guidelines', 'Color Systems', 'Typography Rules', 'Asset Libraries'],
  frontIcon: Palette,
  featureIcons: [Palette, Layers, Pen, Shapes],
  color: "#0EA5E9"
}, {
  title: "Professional Aesthetics",
  subtitle: "Polished & premium",
  description: "Elevate your brand's perceived value with polished, professional design that resonates with your target audience.",
  features: ['Premium Quality', 'Pixel Perfect', 'Print Ready', 'Digital Optimized'],
  frontIcon: Eye,
  featureIcons: [Eye, Star, Sparkles, Image],
  color: "#8B5CF6"
}, {
  title: "Creative Excellence",
  subtitle: "Unique & memorable",
  description: "Stand out from competitors with unique, creative designs that capture attention and communicate your message.",
  features: ['Custom Illustrations', 'Motion Graphics', 'Infographics', 'Icon Design'],
  frontIcon: Wand2,
  featureIcons: [Wand2, Paintbrush, Brush, Sparkles],
  color: "#EC4899"
}];

const graphicsDesignGalleryImages = logoPortfolioImages;

const GraphicsDesign = () => {
  return (
    <div className="min-h-screen bg-zogago-dark">
      <ServicesPageTemplate
        pageTitle="Graphics Design"
        pageDescription="Elevate your brand with eye-catching visual designs that communicate your message effectively and leave a lasting impression on your target audience."
        galleryImages={graphicsDesignGalleryImages}
        services={graphicsDesignServices}
        processSteps={graphicsDesignProcessSteps}
        benefits={[]}
        flipCards={graphicsFlipCardBenefits}
        ctaTitle="Ready to Transform Your Visual Identity?"
        ctaSubtitle="Explore our design portfolio and discover how we can help your brand stand out visually."
        workSectionTitle="Our Graphics Design Work"
      />
    </div>
  );
};

export default GraphicsDesign;
