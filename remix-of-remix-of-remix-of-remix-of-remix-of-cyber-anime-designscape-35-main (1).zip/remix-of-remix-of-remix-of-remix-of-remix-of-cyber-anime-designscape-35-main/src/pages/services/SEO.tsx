import React, { useState } from 'react';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import ServiceShowcase from '../../components/services/ServiceShowcase';
import ServiceHero from '../../components/services/ServiceHero';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { Separator } from '@/components/ui/separator';
import { ChevronRight, Search, BarChart3, Users, X, TrendingUp, Target, Award, Lightbulb, HeadphonesIcon, FileText, LayoutDashboard, LineChart } from 'lucide-react';
import CardFlip from '@/components/ui/flip-card';
import ServiceRelatedCaseStudies from '@/components/services/ServiceRelatedCaseStudies';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { seoFlipCards } from '@/data/standardProcessSteps';

const seoServices = [{
  id: 1,
  title: "Technical SEO Audit",
  description: "Comprehensive analysis of your website's technical health to identify and fix issues that affect search engine visibility.",
  imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=2940",
  route: "/contact",
  galleryImages: ["https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=2940", "https://images.unsplash.com/photo-1555952517-2e8e729e0b44?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&q=80&w=2074", "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80&w=2070"]
}, {
  id: 2,
  title: "Keyword Research & Strategy",
  description: "Data-driven approach to discover high-value keywords that drive qualified traffic and conversions.",
  imageUrl: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=2940",
  route: "/contact",
  galleryImages: ["https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=2940", "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1506097425191-7ad538b29cef?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1526628953301-3e589a6a8b74?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=2070"]
}, {
  id: 3,
  title: "On-Page SEO Optimization",
  description: "Enhance the content, structure, and HTML of your website to improve visibility for specific keywords.",
  imageUrl: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&q=80&w=2940",
  route: "/contact",
  galleryImages: ["https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&q=80&w=2940", "https://images.unsplash.com/photo-1572044162444-ad60f128bdea?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&q=80&w=2072", "https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1564865878688-9a244444042a?auto=format&fit=crop&q=80&w=2070"]
}];

const seoGalleryImages = ["https://images.unsplash.com/photo-1571786256017-aee7a0c009b6?auto=format&fit=crop&q=80&w=1780", "https://images.unsplash.com/photo-1520333789090-1afc82db536a?auto=format&fit=crop&q=80&w=2071", "https://images.unsplash.com/photo-1581092335397-9583eb92d232?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1675466583534-1755fbb2959b?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?auto=format&fit=crop&q=80&w=2074"];

const SEO = () => {
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const handleNextImage = () => {
    setCurrentImageIndex(prev => (prev + 1) % selectedImages.length);
  };
  const handlePrevImage = () => {
    setCurrentImageIndex(prev => prev === 0 ? selectedImages.length - 1 : prev - 1);
  };

  return <>
    <Navbar />
    <div className="relative bg-zogago-dark">
      <ServiceHero
        title="Search Engine Optimization"
        description="Drive organic traffic, increase visibility, and achieve higher rankings with our data-driven SEO strategies tailored for your business goals."
      />


      <div id="services">
        <ServiceShowcase title="Our SEO Services" subtitle="Comprehensive solutions to boost your online visibility and drive organic growth" services={seoServices} />
      </div>

      

      <section className="py-20 relative overflow-hidden">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-zogago-blue to-blue-500">Why Choose Our SEO Services?</h2>
            <p className="text-lg text-zogago-light/70 max-w-3xl mx-auto">Partner with us for data-driven SEO strategies that deliver measurable results</p>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}>
              <CardFlip
                title="Data-Driven Approach"
                subtitle="Analytics that matter"
                description="We base our strategies on comprehensive data analysis, ensuring measurable and impactful results for your business."
                features={['Advanced Analytics', 'Real-Time Tracking', 'Conversion Insights', 'Performance Metrics']}
                frontIcon={BarChart3}
                featureIcons={[BarChart3, Search, TrendingUp, Target]}
                color="#0EA5E9"
              />
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
              <CardFlip
                title="Expert Team"
                subtitle="Industry specialists"
                description="Our SEO specialists have deep expertise across industries, delivering tailored strategies that align with your business goals."
                features={['Certified Experts', 'Industry Knowledge', 'Custom Strategies', 'Dedicated Support']}
                frontIcon={Users}
                featureIcons={[Award, Users, Lightbulb, HeadphonesIcon]}
                color="#8B5CF6"
              />
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }}>
              <CardFlip
                title="Transparent Reporting"
                subtitle="Full visibility always"
                description="Regular, comprehensive reports keep you informed about your campaign's performance and the value we're delivering."
                features={['Monthly Reports', 'KPI Dashboards', 'ROI Tracking', 'Growth Forecasts']}
                frontIcon={FileText}
                featureIcons={[FileText, LayoutDashboard, TrendingUp, LineChart]}
                color="#EC4899"
              />
            </motion.div>
          </div>
        </div>
      </section>

      <ServiceRelatedCaseStudies pageTitle="SEO" />

      <section className="py-20 bg-gradient-to-b from-black/40 to-zogago-dark relative overflow-hidden">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7 }} className="glass-card border border-zogago-blue/20 p-8 md:p-12 max-w-4xl mx-auto text-center relative z-10">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-zogago-blue to-zogago-purple">Ready to Improve Your Search Rankings?</h2>
            <p className="text-lg text-zogago-light/80 mb-8 max-w-2xl mx-auto">Explore our SEO services portfolio and discover how we can help your business grow online.</p>
            <Button className="button-glow" size="lg" onClick={() => window.openContactForm?.()}>
              <span>Let's Work Together</span>
            </Button>
          </motion.div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <Separator className="mb-20 bg-white/10" />
          <motion.h2 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="text-3xl md:text-4xl font-bold mb-4 text-center bg-clip-text text-transparent bg-gradient-to-r from-zogago-purple to-zogago-pink">Our SEO Work</motion.h2>
        </div>
      </section>

      <Dialog open={isGalleryOpen} onOpenChange={setIsGalleryOpen}>
        <DialogContent className="sm:max-w-4xl bg-black/90 border border-white/10 p-0 overflow-hidden">
          <div className="relative w-full h-full">
            <button onClick={() => setIsGalleryOpen(false)} className="absolute top-4 right-4 z-20 bg-black/60 rounded-full p-2 text-white hover:bg-gradient-to-r hover:from-zogago-blue hover:via-zogago-purple hover:to-zogago-pink transition-colors"><X className="w-6 h-6" /></button>
            <div className="relative aspect-video w-full overflow-hidden">
              <img src={selectedImages[currentImageIndex]} alt={`SEO showcase ${currentImageIndex + 1}`} className="w-full h-full object-contain" />
              <div className="absolute inset-0 flex items-center justify-between px-4 opacity-0 hover:opacity-100 transition-opacity">
                <button onClick={handlePrevImage} className="bg-black/60 rounded-full p-4 text-white hover:bg-gradient-to-r hover:from-zogago-blue hover:via-zogago-purple hover:to-zogago-pink transition-colors"><ChevronRight className="w-6 h-6 transform rotate-180" /></button>
                <button onClick={handleNextImage} className="bg-black/60 rounded-full p-4 text-white hover:bg-gradient-to-r hover:from-zogago-blue hover:via-zogago-purple hover:to-zogago-pink transition-colors"><ChevronRight className="w-6 h-6" /></button>
              </div>
            </div>
            <div className="bg-black/80 p-4">
              <h3 className="text-xl font-bold text-white mb-4">SEO Services Gallery</h3>
              <div className="flex gap-2 overflow-x-auto pb-2">
                {selectedImages.map((img, idx) => <div key={idx} onClick={() => setCurrentImageIndex(idx)} className={`cursor-pointer flex-shrink-0 w-20 h-20 rounded overflow-hidden ${idx === currentImageIndex ? 'ring-2 ring-zogago-blue' : 'opacity-70'}`}><img src={img} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" /></div>)}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  </>;
};

export default SEO;
