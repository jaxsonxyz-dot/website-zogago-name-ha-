import React from 'react';
import { Share2, BarChart3, Users, Heart, MessageCircle, TrendingUp, Megaphone, Target, Eye, Zap } from 'lucide-react';
import ServicesPageTemplate from '../../components/services/ServicesPageTemplate';
import ServiceWorkTemplate from '../../components/services/ServiceWorkTemplate';
import { createStandardProcessSteps, socialMediaFlipCards } from '@/data/standardProcessSteps';
import { BenefitFlipCard } from '@/components/services/ServiceBenefitsSection';

const socialMediaProcessSteps = createStandardProcessSteps(socialMediaFlipCards);

const socialMediaServices = [{
  id: 1,
  title: "Social Media Strategy",
  description: "Comprehensive strategy development tailored to your business objectives, audience, and industry landscape.",
  imageUrl: "https://images.unsplash.com/photo-1611926653458-09294b3142bf?auto=format&fit=crop&q=80&w=2070",
  route: "/contact",
  galleryImages: ["https://images.unsplash.com/photo-1611926653458-09294b3142bf?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1557838923-2985c318be48?auto=format&fit=crop&q=80&w=2069", "https://images.unsplash.com/photo-1493612276216-ee3925520721?auto=format&fit=crop&q=80&w=2064", "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80&w=2070"]
}, {
  id: 2,
  title: "Content Creation & Management",
  description: "Eye-catching, engaging content created and managed across all your social media platforms.",
  imageUrl: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=2070",
  route: "/contact",
  galleryImages: ["https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1493612276216-ee3925520721?auto=format&fit=crop&q=80&w=2064", "https://images.unsplash.com/photo-1557838923-2985c318be48?auto=format&fit=crop&q=80&w=2069", "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80&w=2070"]
}, {
  id: 3,
  title: "Paid Advertising Campaigns",
  description: "Strategic paid campaigns across social platforms to maximize reach, engagement, and ROI.",
  imageUrl: "https://images.unsplash.com/photo-1526628953301-3e589a6a8b74?auto=format&fit=crop&q=80&w=2070",
  route: "/contact",
  galleryImages: ["https://images.unsplash.com/photo-1526628953301-3e589a6a8b74?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1611926653458-09294b3142bf?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1557838923-2985c318be48?auto=format&fit=crop&q=80&w=2069", "https://images.unsplash.com/photo-1493612276216-ee3925520721?auto=format&fit=crop&q=80&w=2064"]
}];

const socialMediaFlipCardBenefits: BenefitFlipCard[] = [{
  title: "Brand Awareness",
  subtitle: "Expand your reach",
  description: "Expand your brand's reach and visibility to new audiences across multiple social media platforms.",
  features: ['Viral Content', 'Hashtag Strategy', 'Influencer Collab', 'Cross-Platform'],
  frontIcon: Megaphone,
  featureIcons: [Megaphone, Share2, Heart, Eye],
  color: "#0EA5E9"
}, {
  title: "Community Building",
  subtitle: "Engage & grow",
  description: "Develop an engaged community of followers who interact with and advocate for your brand.",
  features: ['Active Engagement', 'User Content', 'Brand Advocates', 'Loyalty Programs'],
  frontIcon: Users,
  featureIcons: [Users, MessageCircle, Heart, Target],
  color: "#8B5CF6"
}, {
  title: "Measurable Results",
  subtitle: "Track every metric",
  description: "Track the performance of your social media efforts with detailed analytics and ROI reporting.",
  features: ['Live Dashboards', 'ROI Reports', 'Growth Metrics', 'A/B Testing'],
  frontIcon: BarChart3,
  featureIcons: [BarChart3, TrendingUp, Zap, Target],
  color: "#EC4899"
}];

const socialMediaGalleryImages = ["https://images.unsplash.com/photo-1611926653458-09294b3142bf?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1526800544336-d04f0cbfd700?auto=format&fit=crop&q=80&w=2074", "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1557838923-2985c318be48?auto=format&fit=crop&q=80&w=2069"];

const socialMediaWorkSamples = [{
  id: 1, title: "Fashion Brand Campaign", description: "Integrated social media campaign for seasonal product launch.",
  imageUrl: "https://images.unsplash.com/photo-1516251193007-45ef944ab0c6?auto=format&fit=crop&q=80&w=2070",
  detailImages: ["https://images.unsplash.com/photo-1523464862212-d6631d073194?auto=format&fit=crop&q=80&w=1780", "https://images.unsplash.com/photo-1571781565036-d3f759314bab?auto=format&fit=crop&q=80&w=2072", "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&q=80&w=1988"],
  projectInfo: "Cross-platform campaign that increased engagement by 45% and drove a 30% increase in direct sales.", tags: ["Fashion", "Instagram", "Facebook", "Influencer Marketing"]
}, {
  id: 2, title: "Restaurant Social Strategy", description: "Content strategy and management for upscale dining establishment.",
  imageUrl: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=2070",
  detailImages: ["https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1592861956120-e524fc739696?auto=format&fit=crop&q=80&w=2070"],
  projectInfo: "Monthly content calendar resulting in a 70% increase in bookings through social media.", tags: ["Hospitality", "Food Photography", "Instagram", "Local SEO"]
}, {
  id: 3, title: "Product Launch Campaign", description: "Multi-channel social media campaign for tech product launch.",
  imageUrl: "https://images.unsplash.com/photo-1522542550221-31fd19575a2d?auto=format&fit=crop&q=80&w=2070",
  detailImages: ["https://images.unsplash.com/photo-1634157703702-3c124b455499?auto=format&fit=crop&q=80&w=2080", "https://images.unsplash.com/photo-1560472355-536de3962603?auto=format&fit=crop&q=80&w=2070", "https://images.unsplash.com/photo-1585486786500-368597bbe646?auto=format&fit=crop&q=80&w=1974"],
  projectInfo: "Integrated campaign that drove 10,000+ pre-orders for a new tech product.", tags: ["Tech", "Product Launch", "Paid Advertising", "Multi-channel"]
}];

const SocialMediaMarketing = () => {
  return (
    <div className="min-h-screen bg-zogago-dark">
      <ServicesPageTemplate
        pageTitle="Social Media Marketing"
        pageDescription="Grow your online presence with strategic social media marketing designed to engage audiences, build brand loyalty, and drive meaningful business results."
        galleryImages={socialMediaGalleryImages}
        services={socialMediaServices}
        processSteps={socialMediaProcessSteps}
        benefits={[]}
        flipCards={socialMediaFlipCardBenefits}
        ctaTitle="Ready to Amplify Your Social Media Presence?"
        ctaSubtitle="Explore our social media marketing portfolio and discover how we can help your brand stand out online."
        workSectionTitle="Our Social Media Work"
      />
      <ServiceWorkTemplate
        serviceTitle="Social Media Marketing Portfolio"
        serviceDescription="Explore our social media marketing campaigns that showcase our expertise in creating engaging content and driving meaningful results across platforms."
        workSamples={socialMediaWorkSamples}
        backgroundColor="from-zogago-blue/20 to-blue-500/20"
      />
    </div>
  );
};

export default SocialMediaMarketing;
