
// This file is kept for backwards compatibility
// It re-exports all animation utilities from the new modular structure

// Import and re-export everything from animations
export * from './animations';
